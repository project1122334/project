<?php

session_start();
include 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>

    <style>
.banner{background: url(images/parts.png); background-position: center; background-size: cover;height: 50vh;}
.bg-new{background: transparent;}
.bg-green{background-color: #03de1c;}
.text-green{color: #03de1c;}
.h1{
  font-size: 65px; font-weight: 700;}
.btn-green{background-color: #03de1c; width: 190px; height: 47px;}

.logo img {
      width: 50px;
    }
</style>
    </head>



<body>
<div class="banner">
<nav class="navbar navbar-expand-lg bg-new pt-4 px-3">
  <a class="logo" href="#"><img src="images/image.jpg" alt="..."></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon bg-green"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
      <li class="nav-item mx-2 bg-green">
        <a class="nav-link text-white" href="homepage.php">HOME</a>
      </li>
      
     
      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="#">Services</a>
      </li>

      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="#">Accessories</a>
      </li>

      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="#">New Item</a>
      </li>

      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="#">About</a>
      </li>

     
      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="#">Contact Us</a>
      </li>

         
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
      <li class="nav-item mx-2 bg-green">
        <a class="nav-link text-red" style="font-size: 18px;" href="mycart.php">My Cart</a>
      </li>

  </div>
</nav>

<!--page -->
<div class="container-fluid" style="margin-top: 5px;">
     <div class="row">
       <div clas="col-md-12 text-white" style="padding-left: 12%;">
       <h1 style="color: white;">SHOP NOW<br>WITH<br>TATA CARS</h1>
   
       </div>
     </div>
   </div>    
<!--Page End -->

</div>




<div class="container mt-4" >


    <div class="row">
        <div class="col-lg-3">
          <form action="cart.php" method="POST">
                <div class="card" style="border: 2px solid rgb(125,125,235); border-radius: 15px;">
                    <img src="images/fuel.jpg" class="card-img-top" alt="...">
                    <div class="card-body text-centre">
                        <h5 class="card-title">fuel injector</h5>
                        <p class="card-text">Helps To transfer Fuel To Engine</p>
                        <p class="card-text">Price: 10,000</p>
                        <select name="quantity" class="form-select">
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                       </select>
                       <input type="hidden" name="parts" value="Fuel_Injector">
                       <input type="hidden" name="price" value="10000">
                       <button type="submit" name="add_to_cart" class="btn btn-info">Add to Cart</button>
                   
                </div>
               </div>
           </form> 
        </div>

        <div class="col-lg-3">
          <form action="cart.php" method="POST">
                <div class="card" style="border: 2px solid rgb(125,125,235); border-radius: 15px;">
                    <img src="images/oil.png" class="card-img-top" alt="...">
                    <div class="card-body text-centre">
                        <h5 class="card-title">Engine oil</h5>
                        <p class="card-text">Engine oil lubricates,cools and protects internal components</p>
                        <p class="card-text">Price: 1000</p>
                        <select name="quantity" class="form-select">
                           <option value="1">1</option>
                           <option value="2">2</option>
                           <option value="3">3</option>
                      </select>
                       <input type="hidden" name="parts" value="Oil">
                       <input type="hidden" name="price" value="1000">
                       <button type="submit" name="add_to_cart" class="btn btn-info">Add to Cart</button>
                   
                </div>
               </div>
           </form> 
        </div>

        <div class="col-lg-3">
          <form action="cart.php" method="POST">
                <div class="card" style="border: 2px solid rgb(125,125,235); border-radius: 15px;">
                    <img src="images/battery.png" class="card-img-top" alt="...">
                    <div class="card-body text-centre">
                        <h5 class="card-title">battery</h5>
                        <p class="card-text">For Power Consumption In car</p>
                        <p class="card-text">Price: 7000</p>
                        <select name="quantity" class="form-select">
                           <option value="1">1</option>
                           <option value="2">2</option>
                           <option value="3">3</option>
                        </select>
                       <input type="hidden" name="parts" value="Battry">
                       <input type="hidden" name="price" value="7000">
                       <button type="submit" name="add_to_cart" class="btn btn-info">Add to Cart</button>
                   
                </div>
               </div>
           </form> 
        </div>


        <div class="col-lg-3">
          <form action="cart.php" method="POST">
                <div class="card" style="border: 2px solid rgb(125,125,235); border-radius: 15px;">
                    <img src="images/water_pump.jpg" class="card-img-top" alt="...">
                    <div class="card-body text-centre">
                        <h5 class="card-title">Water Pump</h5>
                        <p class="card-text">For Water Supply In Air Conditioning </p>
                        <p class="card-text">Price: 9,500</p>
                        <select name="quantity" class="form-select">
                            <option value="1">1</option>
                            <option value="2">2</option>
                           <option value="3">3</option>
                        </select>
                       <input type="hidden" name="parts" value="Water_Pump">
                       <input type="hidden" name="price" value="9500 ">
                       <button type="submit" name="add_to_cart" class="btn btn-info">Add to Cart</button>
                   
                </div>
               </div>
           </form> 
        </div>



      </div>
     </div>  






     <div class="container mt-3" >
    <div class="row">
        <div class="col-lg-3">
          <form action="cart.php" method="POST">
                <div class="card" style="border: 2px solid rgb(125,125,235); border-radius: 15px;">
                    <img src="images/oilfiltre.jpg" class="card-img-top" alt="...">
                    <div class="card-body text-centre">
                        <h5 class="card-title">Oil filtre</h5>
                        <p class="card-text">For Keeping Oil clear </p>
                        <p class="card-text">Price: 4,500</p>
                        <select name="quantity" class="form-select">
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                       </select>
                       <input type="hidden" name="parts" value="Oil_Filtre">
                       <input type="hidden" name="price" value="4500">
                       <button type="submit" name="add_to_cart" class="btn btn-info">Add to Cart</button>
                   
                </div>
               </div>
           </form> 
        </div>



        <div class="col-lg-3">
          <form action="cart.php" method="POST">
                <div class="card" style="border: 2px solid rgb(125,125,235); border-radius: 15px;">
                    <img src="images/shock_absorber.jpg" class="card-img-top" alt="...">
                    <div class="card-body text-centre">
                        <h5 class="card-title">Shock Absorber</h5>
                        <p class="card-text">Prevents Damage From potholes</p>
                        <p class="card-text">Price: 9,000</p>
                        <select name="quantity" class="form-select">
                            <option value="1">1</option>
                            <option value="2">2</option>
                           <option value="3">3</option>
                        </select>
                       <input type="hidden" name="parts" value="Shock_Absorber">
                       <input type="hidden" name="price" value="9000">
                       <button type="submit" name="add_to_cart" class="btn btn-info">Add to Cart</button>
                   
                </div>
               </div>
           </form> 
        </div>





        <div class="col-lg-3">
          <form action="cart.php" method="POST">
                <div class="card" style="border: 2px solid rgb(125,125,235); border-radius: 15px;">
                    <img src="images/tyre.png" class="card-img-top" alt="...">
                    <div class="card-body text-centre">
                        <h5 class="card-title">Tyre</h5>
                        <p class="card-text">Where the Road Meets Reliability,Trust in a Good Tyre</p>
                        <p class="card-text">Price: 15,000</p>
                        <select name="quantity" class="form-select">
                           <option value="1">1</option>
                           <option value="2">2</option>
                           <option value="3">3</option>
                      </select>
                       <input type="hidden" name="parts" value="Tyre">
                       <input type="hidden" name="price" value="15000">
                       <button type="submit" name="add_to_cart" class="btn btn-info">Add to Cart</button>
                   
                </div>
               </div>
           </form> 
        </div>

        <div class="col-lg-3">
          <form action="cart.php" method="POST">
                <div class="card" style="border: 2px solid rgb(125,125,235); border-radius: 15px;">
                    <img src="images/airfiltre.png" class="card-img-top" alt="...">
                    <div class="card-body text-centre">
                        <h5 class="card-title">Air Filtre</h5>
                        <p class="card-text">Better Air Quality In Car</p>
                        <p class="card-text">Price: 3,000</p>
                        <select name="quantity" class="form-select">
                           <option value="1">1</option>
                           <option value="2">2</option>
                           <option value="3">3</option>
                        </select>
                       <input type="hidden" name="parts" value="Air_Filtre">
                       <input type="hidden" name="price" value="3000">
                       <button type="submit" name="add_to_cart" class="btn btn-info">Add to Cart</button>
                   
                </div>
               </div>
           </form> 
        </div>



      </div>
     </div>  


     <?php
// Connect to the database
include 'connect.php';

// Fetch products
$result = $conn->query("SELECT * FROM products");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accessories</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <div class="row">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="col-lg-3">
                <form action="cart.php" method="POST">
                    <div class="card" style="border: 2px solid rgb(125,125,235); border-radius: 15px;">
                        <?php
                        // Debugging: print the image path
                        $imagePath = "images/" . $row['image'];
                        if (file_exists($imagePath)) {
                            // Display image if it exists
                            echo '<img src="' . $imagePath . '" class="card-img-top" alt="...">';
                        } else {
                            // Show a placeholder or error if the image doesn't exist
                            echo '<img src="images/placeholder.png" class="card-img-top" alt="Placeholder">';
                            echo '<p class="text-danger">Image not found</p>';
                        }
                        ?>
                        <div class="card-body text-center">
                            <h5 class="card-title"><?= htmlspecialchars($row['name']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($row['description']) ?></p>
                            <p class="card-text">Price: <?= htmlspecialchars($row['price']) ?></p>
                            <select name="quantity" class="form-select">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                            <input type="hidden" name="parts" value="<?= htmlspecialchars($row['name']) ?>">
                            <input type="hidden" name="price" value="<?= htmlspecialchars($row['price']) ?>">
                            <button type="submit" name="add_to_cart" class="btn btn-info">Add to Cart</button>
                        </div>
                    </div>
                </form>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>