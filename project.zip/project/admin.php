
<?php

include 'connect.php';
session_start();

// Fetch total users
$query = "SELECT COUNT(*) as totalUsers FROM users";
$result = $conn->query($query);
$totalUsers = $result ? $result->fetch_assoc()['totalUsers'] : 0;

// Fetch total bookings from all three tables
$sqlCarBookings = "SELECT COUNT(*) as totalCarBookings FROM car_bookings";
$sqlTestBookings = "SELECT COUNT(*) as totalTestBookings FROM test_bookings";
$sqlRepairBooking = "SELECT COUNT(*) as totalRepairBooking FROM repair_booking";

$resultCarBookings = mysqli_query($conn, $sqlCarBookings);
$resultTestBookings = mysqli_query($conn, $sqlTestBookings);
$resultRepairBooking = mysqli_query($conn, $sqlRepairBooking);

$totalCarBookings = mysqli_fetch_assoc($resultCarBookings)['totalCarBookings'];
$totalTestBookings = mysqli_fetch_assoc($resultTestBookings)['totalTestBookings'];
$totalRepairBooking = mysqli_fetch_assoc($resultRepairBooking)['totalRepairBooking'];

$totalBookings = $totalCarBookings + $totalTestBookings + $totalRepairBooking;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
    />
    <title>Admin Dashboard</title>
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap");
      body,
      button {
        font-family: "Inter", sans-serif;
      }
      :root {
        --offcanvas-width: 270px;
        --topNavbarHeight: 56px;
      }
      .sidebar {
        width: var(--offcanvas-width);
        position: fixed;
        top: var(--topNavbarHeight);
        bottom: 0;
        left: 0;
        z-index: 100;
        padding: 1rem 0;
        background-color: #343a40;
      }
      .sidebar a {
        color: #fff;
        text-decoration: none;
      }
      .sidebar .nav-link {
        color: #ffffffb3;
      }
      .sidebar .nav-link:hover {
        color: #ffffff;
      }
      .sidebar .nav-link.active {
        background-color: #495057;
        color: #fff;
      }
      main {
        margin-left: var(--offcanvas-width);
        padding: 2rem;
      }
    </style>
  </head>
  <body>
    <!-- top navigation bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container-fluid">
        <a class="navbar-brand me-auto ms-lg-0 ms-3 text-uppercase fw-bold" href="#">
          Admin Dashboard
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#topNavBar"
          aria-controls="topNavBar"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
       
          <ul class="navbar-nav">
            <li class="nav-item dropdown">
              <a
                class="nav-link dropdown-toggle ms-2"
                href="#"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                <i class="bi bi-person-fill"></i>
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="#">Action</a></li>
                <li><a class="dropdown-item" href="#">Another action</a></li>
                <li><a class="dropdown-item" href="#">Something else here</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- top navigation bar -->

    <!-- Sidebar -->
    <div class="sidebar">
      <ul class="nav flex-column">
        <li class="nav-item">
          <a href="admin.php" class="nav-link active">
            <i class="bi bi-house me-2"></i>Dashboard
          </a>
        </li>
        <li class="nav-item">
          <a href="admin/users.php" class="nav-link">
            <i class="bi bi-people me-2"></i>Users
          </a>
        </li>
     
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="bi bi-cart me-2"></i>Purchase
          </a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="bi bi-person-lines-fill me-2"></i>Manage Users
          </a>
        </li>
        <li class="nav-item">
          <a href="admin/feedback.php" class="nav-link">
            <i class="bi bi-chat me-2"></i>Feedback
          </a>
        </li>
        <li class="nav-item mx-2">
        <a href="admin/products.php" class="nav-link">
           <i class="bi bi-cart me-2"></i>Products
        </a>
      </li>
        <li class="nav-item">
  <a href="logout.php" class="nav-link">
    <i class="bi bi-box-arrow-right me-2"></i>Logout
  </a>
</li>


    <!-- Bookings with Submenu -->
    <li class="nav-item">
            <a href="#bookingsSubmenu" class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="bookingsSubmenu">
                <i class="bi bi-calendar-check me-2"></i>Bookings
            </a>
            <ul class="collapse" id="bookingsSubmenu">
                <li class="nav-item">
                    <a href="admin/booking.php" class="nav-link ms-3">Car Booking</a>
                </li>
                <li class="nav-item">
                    <a href="admin/testbooking.php" class="nav-link ms-3">Test Drive Booking</a>
                </li>
                <li class="nav-item">
                    <a href="admin/repair.php" class="nav-link ms-3">Car Repair Booking</a>
                </li>
      </ul>
    </div>
    <!-- Sidebar -->

    <main class="mt-5 pt-3">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <h4>Dashboard</h4>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3 mb-3">
            <div class="card bg-info text-white h-100">
              <div class="card-body py-5">Total Users: <?php echo $totalUsers; ?>
               </div>
              <div class="card-footer d-flex">
              
              <a href="#"> View Details </a>
              
                <span class="ms-auto">
                  <i class="bi bi-chevron-right"></i>
                </span>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="card bg-warning text-dark h-100">
              <div class="card-body py-5">Total Bookings: <?php echo $totalBookings; ?></div>
              <div class="card-footer d-flex">
               <a href="#"> View Details </a>
                <span class="ms-auto">
                  <i class="bi bi-chevron-right"></i>
                </span>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="card bg-success text-white h-100">
              <div class="card-body py-5">Success Card</div>
              <div class="card-footer d-flex">
              <a href="#"> View Details </a>
                <span class="ms-auto">
                  <i class="bi bi-chevron-right"></i>
                </span>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="card bg-danger text-white h-100">
              <div class="card-body py-5">Danger Card</div>
              <div class="card-footer d-flex">
              <a href="#"> View Details </a>
                <span class="ms-auto">
                  <i class="bi bi-chevron-right"></i>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.0.2/dist/chart.min.js"></script>
    <script src="script.js"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
