<?php 
session_start();
include '../connect.php'; // Ensure you include your database connection file

// Handle row removal
if (isset($_GET['remove_id'])) {
    $remove_id = intval($_GET['remove_id']);
    $delete_sql = "DELETE FROM car_bookings WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $remove_id);
    $stmt->execute();
    $stmt->close();
    header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page to show updated data
    exit();
}

$sql = "SELECT * FROM car_bookings";
$result = mysqli_query($conn, $sql); // Replace `$conn` with your connection variable
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
    />
    <title>Admin - User Management</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
@import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap");
body,
button {
  font-family: "Inter", sans-serif;
}
:root {
  --offcanvas-width: 270px;
  --topNavbarHeight: 56px;
}

body {
  margin: 0;
  padding: 0;
  overflow-x: hidden;
}

.sidebar {
  width: var(--offcanvas-width);
  position: fixed;
  top: var(--topNavbarHeight);
  bottom: 0;
  left: 0;
  z-index: 100;
  padding: 1rem 0;
  background-color: #343a40;
}

.sidebar a {
  color: #fff;
  text-decoration: none;
}

.sidebar .nav-link {
  color: #ffffffb3;
}

.sidebar .nav-link:hover {
  color: #ffffff;
}

.sidebar .nav-link.active {
  background-color: #495057;
  color: #fff;
}

main {
  margin-left: var(--offcanvas-width);
  padding: 2rem;
}

.container {
  margin-top: 1rem; /* Adjust as necessary to avoid overlap with fixed navbar */
}

.table thead tr {
  background-color: #343a40; /* Dark Gray for Header */
  color: white; /* White text */
}

.table tbody tr {
  background-color: #2C2C2C; /* Slightly lighter dark gray for rows */
  color: white; /* White text */
}

.table tbody tr:hover {
  background-color: #3e3e3e; /* Slightly brighter dark gray for row hover */
}
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand me-auto ms-lg-0 ms-3 text-uppercase fw-bold" href="#">
            Admin Dashboard
        </a>
        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#topNavBar"
            aria-controls="topNavBar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a href="../admin.php" class="nav-link active">
                <i class="bi bi-house me-2"></i>Dashboard
            </a>
        </li>
        <li class="nav-item">
            <a href="users.php" class="nav-link">
                <i class="bi bi-people me-2"></i>Users
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-cart me-2"></i>Purchase
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-person-lines-fill me-2"></i>Manage Users
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-chat me-2"></i>Feedback
            </a>
        </li>
        <li class="nav-item">
            <a href="#bookingsSubmenu" class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="bookingsSubmenu">
                <i class="bi bi-calendar-check me-2"></i>Bookings
            </a>
            <ul class="collapse" id="bookingsSubmenu">
                <li class="nav-item">
                    <a href="booking.php" class="nav-link ms-3">Car Booking</a>
                </li>
                <li class="nav-item">
                    <a href="testbooking.php" class="nav-link ms-3">Test Drive Booking</a>
                </li>
                <li class="nav-item">
                    <a href="?type=car_repair_booking" class="nav-link ms-3">Car Repair Booking</a>
                </li>
    </ul>
</div>

<!-- Main content -->
<main>
    <div class="container">
        <h1 class="mb-2">User Bookings</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Car Model</th>
                    <th>Booking Date</th>
                    <th>Contact Number</th>
                    <th>Address</th>
                    <th>Car Color</th>
                    <th>Payment Type</th>
                    <th>Insurance Type</th>
                    <th>Aadhar Number</th>
                    <th>Actions</th> <!-- Add an Actions column for buttons -->
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id']); ?></td>
                            <td><?php echo htmlspecialchars($row['firstName']); ?></td>
                            <td><?php echo htmlspecialchars($row['lastName']); ?></td>
                            <td><?php echo htmlspecialchars($row['carModel']); ?></td>
                            <td><?php echo htmlspecialchars($row['bookingDate']); ?></td>
                            <td><?php echo htmlspecialchars($row['contactNumber']); ?></td>
                            <td><?php echo htmlspecialchars($row['address']); ?></td>
                            <td><?php echo htmlspecialchars($row['carColor']); ?></td>
                            <td><?php echo htmlspecialchars($row['paymentType']); ?></td>
                            <td><?php echo htmlspecialchars($row['insuranceType']); ?></td>
                            <td><?php echo htmlspecialchars($row['aadharNumber']); ?></td>
                            <td>
                                <a href="?remove_id=<?php echo htmlspecialchars($row['id']); ?>" 
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Are you sure you want to remove this booking?');">
                                   Remove
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="12">No bookings found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
