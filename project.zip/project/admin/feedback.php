<?php
include '../connect.php';
session_start();

// Fetch all feedback entries
$query = "SELECT id, firstName, lastName, name, email, message, services FROM contact";
$result = $conn->query($query);

if ($result) {
    // Count the total number of feedback entries
    $totalFeedback = $result->num_rows;
} else {
    $totalFeedback = 0; // Default to 0 if the query fails
}

// Handle deletion of feedback
if (isset($_GET['remove_id'])) {
    $deleteId = $_GET['remove_id'];
    $deleteQuery = "DELETE FROM contact WHERE id = ?";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bind_param("i", $deleteId);

    if ($stmt->execute()) {
        echo "<script>
                alert('Feedback deleted successfully!');
                window.location.href = 'feedback.php';
              </script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
    />
    <title>Admin - Test Drive Bookings</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
@import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap");
body,
button {
  font-family: "Inter", sans-serif;
}
:root {
  --offcanvas-width: 270px;
  --topNavbarHeight: 56px;
}

body {
  margin: 0;
  padding: 0;
  overflow-x: hidden;
}

.sidebar {
  width: var(--offcanvas-width);
  position: fixed;
  top: var(--topNavbarHeight);
  bottom: 0;
  left: 0;
  z-index: 100;
  padding: 1rem 0;
  background-color: #343a40;
}

.sidebar a {
  color: #fff;
  text-decoration: none;
}

.sidebar .nav-link {
  color: #ffffffb3;
}

.sidebar .nav-link:hover {
  color: #ffffff;
}

.sidebar .nav-link.active {
  background-color: #495057;
  color: #fff;
}


main {
        margin-left: var(--offcanvas-width);
        padding: 2rem;
      }
      .table {
        background-color: #343a40; /* Dark Gray for Table Background */
        color: white; /* White text */
      }
      .table thead th {
        background-color: #495057; /* Slightly lighter gray for header */
        color: white;
      }
      .table tbody tr {
        background-color: #2C2C2C; /* Slightly lighter dark gray for rows */
      }
      .table tbody tr:hover {
        background-color: #3e3e3e; /* Slightly brighter dark gray for row hover */
      }
      .table td, .table th {
        padding: 1rem;
        vertical-align: middle;
      }
      .table th {
        text-align: center;
      }
      .table td {
        text-align: left;
      }
      .total-feedback {
        font-size: 1.25rem;
        margin-bottom: 1rem;
      }
      .btn-delete {
        color: #dc3545; /* Red color for delete button */
        background-color: transparent;
        border: none;
        cursor: pointer;
      }
      .btn-delete:hover {
        text-decoration: underline;
      }

</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand me-auto ms-lg-0 ms-3 text-uppercase fw-bold" href="#">
            Admin Dashboard
        </a>
        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#topNavBar"
            aria-controls="topNavBar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a href="../admin.php" class="nav-link active">
                <i class="bi bi-house me-2"></i>Dashboard
            </a>
        </li>
        <li class="nav-item">
            <a href="users.php" class="nav-link">
                <i class="bi bi-people me-2"></i>Users
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-cart me-2"></i>Purchase
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-person-lines-fill me-2"></i>Manage Users
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-chat me-2"></i>Feedback
            </a>
        </li>
        <li class="nav-item">
            <a href="#bookingsSubmenu" class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="bookingsSubmenu">
                <i class="bi bi-calendar-check me-2"></i>Bookings
            </a>
            <ul class="collapse" id="bookingsSubmenu">
                <li class="nav-item">
                    <a href="booking.php" class="nav-link ms-3">Car Booking</a>
                </li>
                <li class="nav-item">
                    <a href="testbooking.php" class="nav-link ms-3">Test Drive Booking</a>
                </li>
                <li class="nav-item">
                    <a href="?type=car_repair_booking" class="nav-link ms-3">Car Repair Booking</a>
                </li>
            </ul>
        </li>
    </ul>
</div>



<!-- Main content -->
<main class="mt-5 pt-3">
    <div class="container-fluid">
        <p class="total-feedback">Total Feedback Entries: <?php echo $totalFeedback; ?></p>

        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Message</th>
                    <th>Services</th>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($totalFeedback > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['firstName']) . "</td>"; 
                        echo "<td>" . htmlspecialchars($row['lastName']) . "</td>"; 
                        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['message']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['services']) . "</td>";
                       ?>
                             <td>
                        <a href="?remove_id=<?php echo htmlspecialchars($row['id']); ?>" 
                        class="btn btn-danger btn-sm"
                        onclick="return confirm('Are you sure you want to remove this booking?');">
                        Remove
                     </a>
                     </td>
<?php
                        echo "</tr>";
                    }
                } else {    
                    echo "<tr><td colspan='5'>No feedback entries found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</main>



<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
