<?php 
session_start();
include '../connect.php'; // Ensure you include your database connection file

// Handle row removal
if (isset($_GET['remove_id'])) {
    $remove_id = intval($_GET['remove_id']);
    $delete_sql = "DELETE FROM repair_booking WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $remove_id);
    $stmt->execute();
    $stmt->close();
    header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page to show updated data
    exit();
}

$sql = "SELECT * FROM repair_booking";
$result = mysqli_query($conn, $sql); // Replace `$conn` with your connection variable
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
    />
    <title>Admin - Test Drive Bookings</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
@import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap");
body,
button {
  font-family: "Inter", sans-serif;
}
:root {
  --offcanvas-width: 270px;
  --topNavbarHeight: 56px;
}

body {
  margin: 0;
  padding: 0;
  overflow-x: hidden;
}

.sidebar {
  width: var(--offcanvas-width);
  position: fixed;
  top: var(--topNavbarHeight);
  bottom: 0;
  left: 0;
  z-index: 100;
  padding: 1rem 0;
  background-color: #343a40;
}

.sidebar a {
  color: #fff;
  text-decoration: none;
}

.sidebar .nav-link {
  color: #ffffffb3;
}

.sidebar .nav-link:hover {
  color: #ffffff;
}

.sidebar .nav-link.active {
  background-color: #495057;
  color: #fff;
}

main {
  margin-left: var(--offcanvas-width);
  padding: 2rem;
}

.container {
  margin-top: 1rem; /* Adjust as necessary to avoid overlap with fixed navbar */
}

.table thead tr {
  background-color: #343a40; /* Dark Gray for Header */
  color: white; /* White text */
}

.table tbody tr {
  background-color: #2C2C2C; /* Slightly lighter dark gray for rows */
  color: white; /* White text */
}

.table tbody tr:hover {
  background-color: #3e3e3e; /* Slightly brighter dark gray for row hover */
}
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand me-auto ms-lg-0 ms-3 text-uppercase fw-bold" href="#">
            Admin Dashboard
        </a>
        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#topNavBar"
            aria-controls="topNavBar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a href="../admin.php" class="nav-link active">
                <i class="bi bi-house me-2"></i>Dashboard
            </a>
        </li>
        <li class="nav-item">
            <a href="users.php" class="nav-link">
                <i class="bi bi-people me-2"></i>Users
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-cart me-2"></i>Purchase
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-person-lines-fill me-2"></i>Manage Users
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-chat me-2"></i>Feedback
            </a>
        </li>
        <li class="nav-item">
            <a href="#bookingsSubmenu" class="nav-link" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="bookingsSubmenu">
                <i class="bi bi-calendar-check me-2"></i>Bookings
            </a>
            <ul class="collapse" id="bookingsSubmenu">
                <li class="nav-item">
                    <a href="booking.php" class="nav-link ms-3">Car Booking</a>
                </li>
                <li class="nav-item">
                    <a href="testbooking.php" class="nav-link ms-3">Test Drive Booking</a>
                </li>
                <li class="nav-item">
                    <a href="?type=car_repair_booking" class="nav-link ms-3">Car Repair Booking</a>
                </li>
            </ul>
        </li>
    </ul>
</div>




<main>
    <div class="container">
        <h2>Car Repair Bookings</h2>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">id</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Car Model</th>
                    <th scope="col">Damage Type</th>
                    <th scope="col">other damage</th>
                    <th scope="col">Contact Number</th>
                    <th scope="col">Repair Date</th>
                    <th scope="col">Aadhar Number</th>
                    <th scope="col">Photo</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <th scope="row"><?php echo $row['id']; ?></th>
                        <td><?php echo $row['firstName']; ?></td>
                        <td><?php echo $row['lastName']; ?></td>
                        <td><?php echo $row['carModel']; ?></td>
                        <td><?php echo $row['damageType']; ?></td>
                        <td><?php echo $row['otherDamage']; ?></td>
                        <td><?php echo $row['contactNumber']; ?></td>
                        <td><?php echo $row['repairDate']; ?></td>
                        <td><?php echo $row['aadharNumber']; ?></td>
                        <td>
                            <?php if (!empty($row['photoPath'])): ?>
                                <a href="<?php echo $row['photoPath']; ?>" target="_blank">View Photo</a>
                            <?php else: ?>
                                No Photo
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="?remove_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Remove</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</main>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
