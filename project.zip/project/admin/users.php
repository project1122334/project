<?php
include '../connect.php';
session_start();

// Handle row removal
if (isset($_GET['remove_id'])) {
    $remove_id = intval($_GET['remove_id']);
    $delete_sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($delete_sql);
    $stmt->bind_param("i", $remove_id);
    $stmt->execute();
    $stmt->close();
    header("Location: ".$_SERVER['PHP_SELF']); // Refresh the page to show updated data
    exit();
}


// Fetch all users
$query = "SELECT id, firstName, lastName, email, profile_photo  FROM users";
$result = $conn->query($query);

if ($result) {
    // Count the total number of users
    $totalUsers = $result->num_rows;
} else {
    $totalUsers = 0; // Default to 0 if the query fails
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"
    />
    <title>Admin - User Management</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>

       @import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap");
      body,
      button {
        font-family: "Inter", sans-serif;
      }
      :root {
        --offcanvas-width: 270px;
        --topNavbarHeight: 56px;
      }
      .sidebar {
        width: var(--offcanvas-width);
        position: fixed;
        top: var(--topNavbarHeight);
        bottom: 0;
        left: 0;
        z-index: 100;
        padding: 1rem 0;
        background-color: #343a40;
      }
      .sidebar a {
        color: #fff;
        text-decoration: none;
      }
      .sidebar .nav-link {
        color: #ffffffb3;
      }
      .sidebar .nav-link:hover {
        color: #ffffff;
      }
      .sidebar .nav-link.active {
        background-color: #495057;
        color: #fff;
      }
      main {
        margin-left: var(--offcanvas-width);
        padding: 2rem;
      }
      .table thead tr {
            background-color: #343a40; /* Dark Gray for Header */
            color: white; /* White text */
        }

        .table tbody tr {
            background-color: #2C2C2C; /* Slightly lighter dark gray for rows */
            color: white; /* White text */
        }

        .table tbody tr:hover {
            background-color: #3e3e3e; /* Slightly brighter dark gray for row hover */
        }

    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand me-auto ms-lg-0 ms-3 text-uppercase fw-bold" href="#">
            Admin Dashboard
        </a>
        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#topNavBar"
            aria-controls="topNavBar"
            aria-expanded="false"
            aria-label="Toggle navigation"
        >
            <span class="navbar-toggler-icon"></span>
        </button>
       
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a href="../admin.php" class="nav-link active">
                <i class="bi bi-house me-2"></i>Dashboard
            </a>
        </li>
        <li class="nav-item">
            <a href="users.php" class="nav-link">
                <i class="bi bi-people me-2"></i>Users
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-cart me-2"></i>Purchase
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-person-lines-fill me-2"></i>Manage Users
            </a>
        </li>
        <li class="nav-item">
            <a href="#" class="nav-link">
                <i class="bi bi-chat me-2"></i>Feedback
            </a>
        </li>

        <li class="nav-item">
      <a href="booking.php" class="nav-link">
        <i class="bi bi-calendar-check me-2"></i>Bookings
      </a>
    </li>
    </ul>
</div>

<!-- Main content -->
<main class="mt-5 pt-3">
    <div class="container-fluid">
        <p>Total Users: <?php echo $totalUsers; ?></p>

        <table class="table">
            <thead>
                <tr>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Profile Picture</th>
                    <th>Actions</th> <!-- Add an Actions column for buttons -->
                </tr>
            </thead>
            <tbody>
                <?php
                if ($totalUsers > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $profilePhoto = $row['profile_photo'] ? $row['profile_photo'] : 'default-profile.png'; // Fallback if no photo                         echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['firstName']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['lastName']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                        echo "<td><img src='../uploads/" . htmlspecialchars($profilePhoto) . "' alt='Profile Photo' style='width: 50px; height: 50px;'></td>";
                        ?>
                        <td>
                   <a href="?remove_id=<?php echo htmlspecialchars($row['id']); ?>" 
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Are you sure you want to remove this user?');">
                   Remove
                </a>
                </td>
<?php
                        echo "</tr>";
                    }
                } else {    
                    echo "<tr><td colspan='3'>No users found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</main>

<!-- Bootstrap JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>
