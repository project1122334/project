<?php 
session_start();
include 'connect.php'; // Ensure you include your database connection file

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart</title>

    <style>
     /* Existing CSS */
.banner {
    background: url(images/book2.jpg);
    background-position: center;
    background-size: cover;
    height: 70vh;
}

.bg-new {
    background: transparent;
}

.bg-green {
    background-color: #03de1c;
}

.text-green {
    color: #03de1c;
}

.h1 {
    font-size: 65px;
    font-weight: 700;
}

.btn-green {
    background-color: #03de1c;
    width: 190px;
    height: 47px;
}

.logo img {
    width: 50px;
}

.row {
    display: flex;
    justify-content: center;
}

button.btn-primary {
    width: 200px;
}

/* Adjusted CSS */
body, html {
    margin: 0;
    padding: 0;
}

.container-fluid {
    padding: 0;
    margin-bottom: 0;
}

.booking-section {
    width: 100%;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #f4f4f4;
    margin-top: -20px;
}

.container {
    width: 100%;
    max-width: 600px;
    padding: 20px;
    background-color: white;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
    border-radius: 15px;
    text-align: center;
    transition: all 0.3s ease-in-out;
}

.container:hover {
    box-shadow: 0 0 25px rgba(0, 0, 0, 0.4);
}

h1 {
    font-size: 28px;
    margin-bottom: 20px;
    color: #333;
    font-weight: bold;
}

.dropdown select {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 100%;
    transition: border 0.3s ease;
}

.dropdown select:focus {
    border-color: #007bff;
    outline: none;
}

.form-container {
    display: none;
}

.form-container.active {
    display: block;
}

form {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
}

label {
    font-weight: bold;
    margin-bottom: 5px;
    color: #555;
}

input, select, textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-bottom: 15px;
    transition: border 0.3s ease;
}

input:focus, select:focus, textarea:focus {
    border-color: #007bff;
    outline: none;
}

input[type="submit"] {
    width: auto;
    align-self: center;
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}

input[type="text"], input[type="date"], input[type="time"], textarea {
    font-size: 16px;
}

select {
    font-size: 16px;
}
        

.car-images img {
            width: 150px;
            height: 100px;
            margin-right: 10px;
            cursor: pointer;
            border: 2px solid transparent;
            border-radius: 5px;
        }

        .car-images img:hover {
            border: 2px solid #03de1c;
        }
    </style>
</head>

<body>
    <!-- Banner and top content -->
    <div class="banner">
        <nav class="navbar navbar-expand-lg bg-new pt-4 px-3">
            <a class="logo" href="#"><img src="images/image.jpg" alt="..."></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon bg-green"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item mx-2 bg-green">
                        <a class="nav-link text-white" href="homepage.php">HOME</a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="#">Services</a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="accessories.php">Accessories</a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="#">New Item</a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="#">About</a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="#">Contact Us</a>
                    </li>

                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item mx-2 bg-green">
                    <a class="nav-link text-red" style="font-size: 18px;" href="submenu/status.php">My Booking</a>
                   </li>


                </ul>
            </div>
        </nav>

        <!-- Page Content -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 text-white" style="padding-right: 19cm;">
                    <h1>RIDE RIGHT<br>BOOK RIGHT</h1>
                </div>
            </div>
        </div>
    </div>

    <!-- Booking Content -->
    <div class="booking-section">
        <div class="container">
            <h1>Book an Appointment</h1>
            <div class="dropdown">
                <select id="bookingOptions">
                    <option value="0">Select an Option</option>
                    <option value="carBooking">Car Booking</option>
                    <option value="testDrive">Book Test Drive</option>
                    <option value="carRepair">Car Repair</option>
                </select>
            </div>

            <!-- Car Booking Form -->
            <div id="carBookingForm" class="form-container">
    <h3>Car Booking</h3>
    <form action="car_booking.php" method="post">


    <div class="car-gallery">
                    <h4>Select a Car Model:</h4>
                    <div class="car-images">
                        <img src="images/cars/harrier.png" alt="Harrier" data-car-model="harrier" onclick="selectCarModel(this)">
                        <img src="images/cars/safari.png" alt="Safari" data-car-model="safari" onclick="selectCarModel(this)">
                        <img src="images/cars/hexa.jpg" alt="Hexa" data-car-model="hexa" onclick="selectCarModel(this)">
                        <img src="images/cars/nexon.png" alt="Nexon" data-car-model="nexon" onclick="selectCarModel(this)">
                        <img src="images/cars/nexonev.jpg" alt="Nexon EV" data-car-model="nexonEv" onclick="selectCarModel(this)">
                    </div>
                </div>


        <!-- Car Model Dropdown -->
        <label for="carModel">Car Model:</label>
        <select id="carModel" name="carModel" required>
            <option value="">Select a Car Model</option>
            <option value="harrier">Harrier</option>
            <option value="safari">Safari</option>
            <option value="punch">Punch</option>
            <option value="nexon">Nexon</option>
            <option value="nexonEv">Nexon EV</option>
            <option value="hexa">Hexa</option>
            <option value="tigor">Tigor</option>
            <option value="curve">Curve</option>
            <option value="avinya">Avinya</option>
        </select><br><br>

        <!-- Contact Number -->
        <label for="contactNumber">Contact Number:</label>
        <input type="text" id="contactNumber" name="contactNumber" pattern="[6-9][0-9]{9}" title="Contact number must be 10 digits and start with 6, 7, 8, or 9" required><br><br>

        <!-- Address -->
        <label for="address">Address:</label>
        <textarea id="address" name="address" rows="4" required></textarea><br><br>

        <!-- Car Color Dropdown -->
        <label for="carColor">Color:</label>
        <select id="carColor" name="carColor" required>
            <option value="">Select a Color</option>
            <option value="blue">Blue</option>
            <option value="green">Green</option>
            <option value="yellow">Yellow</option>
            <option value="orange">Orange</option>
            <option value="purple">Purple</option>
            <option value="pink">Pink</option>
            <option value="brown">Brown</option>
            <option value="black">Black</option>
            <option value="white">White</option>
        </select><br><br>

        <!-- Payment Type -->
        <label for="paymentType">Type of Payment:</label>
        <select id="paymentType" name="paymentType" required>
            <option value="">Select Payment Type</option>
            <option value="loan">Loan</option>
            <option value="fullPayment">Full Payment</option>
        </select><br><br>

        <!-- Insurance Type -->
        <label for="insuranceType">Insurance Type:</label>
        <select id="insuranceType" name="insuranceType" required>
            <option value="">Select Insurance Type</option>
            <option value="collisionDamage">Collision Damage</option>
            <option value="theftProtection">Theft Protection</option>
            <option value="liabilityInsurance">Liability Insurance</option>
            <option value="personalAccidentInsurance">Personal Accident Insurance</option>
        </select><br><br>

        <!-- Aadhar Number -->
        <label for="aadharNumber">Aadhar Number:</label>
        <input type="text" id="aadharNumber" name="aadharNumber" pattern="[0-9]{12}" title="Aadhar number must be 12 digits" required><br><br>

        <!-- Booking Date -->
        <label for="bookingDate">Booking Date:</label>
        <input type="date" id="bookingDate" name="bookingDate" required><br><br>

        <!-- Submit Button -->
        <input type="submit" value="Book Car">
    </form>
</div>

            <!-- Test Drive Form -->
            <div id="testDriveForm" class="form-container">
    <h3>Book Test Drive</h3>
    <form action="car_booking.php" method="post">
        <label for="fullName">Full Name:</label>
        <input type="text" id="fullName" name="fullName" required><br><br>

        <label for="phoneNumber">Phone Number:</label>
        <input type="text" id="phoneNumber" name="phoneNumber" pattern="[6789][0-9]{9}" required><br><br>

        <label for="carModel">Car Model:</label>
        <select id="carModel" name="carModel" onchange="updateFuelOptions()" required>
            <option value="Safari">Safari</option>
            <option value="Hexa">Hexa</option>
            <option value="Tiago">Tiago</option>
            <option value="Nexon">Nexon</option>
            <option value="Harrier">Harrier</option>
            <option value="Punch">Punch</option>
            <option value="Curve">Curve</option>
            <option value="Avinya">Avinya</option>
        </select><br><br>

        <label for="testDriveDate">Test Drive Date:</label>
        <input type="date" id="testDriveDate" name="testDriveDate" required><br><br>

        <label for="testDriveTime">Test Drive Time:</label>
        <input type="time" id="testDriveTime" name="testDriveTime" required><br><br>

        <label for="pickupLocation">Pickup Location:</label>
        <select id="pickupLocation" name="pickupLocation" onchange="toggleLocationInput()" required>
            <option value="Enter Location">Enter Location</option>
            <option value="At Showroom">At Showroom</option>
        </select>
        <input type="text" id="customLocation" name="customLocation" placeholder="Enter your location" style="display:none;"><br><br>

        <label for="aadharCard">Aadhar Card Number:</label>
        <input type="text" id="aadharCard" name="aadharCard" pattern="[0-9]{12}" required><br><br>

        <label for="transmissionType">Transmission Type:</label>
        <select id="transmissionType" name="transmissionType" required>
            <option value="Auto">Auto</option>
            <option value="Manual">Manual</option>
        </select><br><br>

        <label for="fuelType">Fuel Type:</label>
        <select id="fuelType" name="fuelType" required>
            <option value="Diesel">Diesel</option>
            <option value="Petrol">Petrol</option>
            <option value="CNG">CNG</option>
        </select><br><br>

        <input type="submit" value="Book Test Drive">
    </form>
</div>

<script>
    function toggleLocationInput() {
        var pickupLocation = document.getElementById("pickupLocation").value;
        var customLocation = document.getElementById("customLocation");
        if (pickupLocation === "Enter Location") {
            customLocation.style.display = "block";
            customLocation.required = true;
        } else {
            customLocation.style.display = "none";
            customLocation.required = false;
        }
    }

    function updateFuelOptions() {
        var carModel = document.getElementById("carModel").value;
        var fuelType = document.getElementById("fuelType");
        if (carModel === "Nexon EV") {
            fuelType.innerHTML = '<option value="No Fuel">No Fuel</option>';
        } else {
            fuelType.innerHTML = '<option value="Diesel">Diesel</option><option value="Petrol">Petrol</option><option value="CNG">CNG</option>';
        }
    }
</script>


            <!-- Car Repair Form -->
            <div id="carRepairForm" class="form-container">
    <h3>Car Repair</h3>
    <form action="car_booking.php" method="post">
        <label for="carModel">Car Model:</label>
        <input type="text" id="carModel" name="carModel" required><br><br>

        <label for="damageType">Damage Type:</label>
        <select id="damageType" name="damageType" required>
            <optgroup label="Engine">
                <option value="overheating">Overheating</option>
                <option value="oil_pressure">Oil Pressure</option>
                <option value="fuel_pump_failure">Fuel Pump Failure</option>
                <option value="wiring_problem">Wiring Problem</option>
            </optgroup>
            <optgroup label="Body">
                <option value="dent">Dent</option>
                <option value="scratch">Scratch</option>
                <option value="rust">Rust</option>
                <option value="broken_window">Broken Window</option>
            </optgroup>
            <optgroup label="Interior">
                <option value="dashboard_damage">Dashboard Damage</option>
                <option value="steering_wheel_damage">Steering Wheel Damage</option>
                <option value="speaker_damage">Speaker Damage</option>
            </optgroup>
            <optgroup label="Others">
                <option value="other">Other (please specify)</option>
            </optgroup>
        </select><br><br>

        <label for="otherDamage">If Other, Specify:</label>
        <input type="text" id="otherDamage" name="otherDamage"><br><br>

        <label for="contactNumber">Contact Number:</label>
        <input type="tel" id="contactNumber" name="contactNumber" pattern="[6-9]{1}[0-9]{9}" required><br><br>

        <label for="repairDate">Repair Date:</label>
        <input type="date" id="repairDate" name="repairDate" required><br><br>

        <label for="aadharNumber">Aadhar Card Number:</label>
        <input type="text" id="aadharNumber" name="aadharNumber" pattern="[0-9]{12}" required><br><br>


        <label for="damagePhoto">Upload Photo (optional):</label>
        <input type="file" id="damagePhoto" name="damagePhoto" accept="image/*"><br><br>


        <input type="submit" value="Book Repair">
    </form>
</div>

        </div>
    </div>

    <script>
        document.getElementById('bookingOptions').addEventListener('change', function() {
            var selectedValue = this.value;
            var forms = document.querySelectorAll('.form-container');
            forms.forEach(function(form) {
                form.classList.remove('active');
            });

            if (selectedValue === 'carBooking') {
                document.getElementById('carBookingForm').classList.add('active');
            } else if (selectedValue === 'testDrive') {
                document.getElementById('testDriveForm').classList.add('active');
            } else if (selectedValue === 'carRepair') {
                document.getElementById('carRepairForm').classList.add('active');
            }
        });
    </script>


<script>
function selectCarModel(image) {
    // Get the car model from the data attribute of the clicked image
    var carModel = image.getAttribute('data-car-model');

    // Set the car model in the dropdown
    document.getElementById('carModel').value = carModel;
}
</script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
