<?php 
session_start();
include 'connect.php'; // Ensure you include your database connection file

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    echo "<script>alert('Please login to book now.'); window.location.href = 'login.php';</script>";
    exit();
}

// Process the Car Booking Form if submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['bookingDate'])) {
    $carModel = $_POST['carModel'];
    $bookingDate = $_POST['bookingDate'];
    $contactNumber = $_POST['contactNumber'];
    $address = $_POST['address'];
    $carColor = $_POST['carColor'];
    $paymentType = $_POST['paymentType'];
    $insuranceType = $_POST['insuranceType'];
    $aadharNumber = $_POST['aadharNumber'];
/*
    // Validate the input
    if (empty($carModel) || empty($bookingDate) || empty($contactNumber) || empty($address) || empty($carColor) || empty($paymentType) || empty($insuranceType) || empty($aadharNumber)) {
        echo "<script>alert('All fields are required.'); history.back();</script>";
        exit();
    }

    if (!preg_match('/^[6789]\d{9}$/', $contactNumber)) {
        echo "<script>alert('Contact number must be 10 digits starting with 6, 7, 8, or 9.'); history.back();</script>";
        exit();
    }

    if (!preg_match('/^\d{12}$/', $aadharNumber)) {
        echo "<script>alert('Aadhar number must be 12 digits.'); history.back();</script>";
        exit();
    } */

    // Store the booking details
    $firstName = $_SESSION['firstName'];
    $lastName = $_SESSION['lastName'];
    
    $stmt = $conn->prepare("INSERT INTO car_bookings (firstName, lastName, carModel, bookingDate, contactNumber, address, carColor, paymentType, insuranceType, aadharNumber) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssss", $firstName, $lastName, $carModel, $bookingDate, $contactNumber, $address, $carColor, $paymentType, $insuranceType, $aadharNumber);

    if ($stmt->execute()) {
        echo "<script>alert('Car booking applied successfully.'); window.location.href = 'homepage.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); history.back();</script>";
    }
}

// Process the Test Drive Booking Form if submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['testDriveDate'])) {
    $fullName = $_POST['fullName'];
    $phoneNumber = $_POST['phoneNumber'];
    $carModel = $_POST['carModel'];
    $testDriveDate = $_POST['testDriveDate'];
    $testDriveTime = $_POST['testDriveTime'];
    $pickupLocation = $_POST['pickupLocation'];
    $customLocation = isset($_POST['customLocation']) ? $_POST['customLocation'] : null;
    $aadharCard = $_POST['aadharCard'];
    $transmissionType = $_POST['transmissionType'];
    $fuelType = $_POST['fuelType'];

    // Ensure all fields are filled
    if (empty($fullName) || empty($phoneNumber) || empty($carModel) || empty($testDriveDate) || empty($testDriveTime) || empty($pickupLocation) || empty($aadharCard) || empty($transmissionType) || empty($fuelType)) {
        echo "<script>alert('All fields are required.'); history.back();</script>";
        exit();
    }
/*
    // Validate the phone number and Aadhar card number
    if (!preg_match('/^[6789]\d{9}$/', $phoneNumber)) {
        echo "<script>alert('Phone number must be 10 digits starting with 6, 7, 8, or 9.'); history.back();</script>";
        exit();
    }

    if (!preg_match('/^\d{12}$/', $aadharCard)) {
        echo "<script>alert('Aadhar card number must be 12 digits.'); history.back();</script>";
        exit();
    }*/

    // Store the test drive booking details in the database
    $firstName = $_SESSION['firstName'];
    $lastName = $_SESSION['lastName'];
    
    $stmt = $conn->prepare("INSERT INTO test_bookings (firstName, lastName, fullName, phoneNumber, carModel, testDriveDate, testDriveTime, pickupLocation, customLocation, aadharCard, transmissionType, fuelType) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssssssss", $firstName, $lastName, $fullName, $phoneNumber, $carModel, $testDriveDate, $testDriveTime, $pickupLocation, $customLocation, $aadharCard, $transmissionType, $fuelType);

    if ($stmt->execute()) {
        echo "<script>alert('Test drive booked successfully.'); window.location.href = 'homepage.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); history.back();</script>";
    }
}


// Process the Car Repair Form if submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['repairDate'])) {
    $carModel = $_POST['carModel'];
    $damageType = $_POST['damageType'];
    $otherDamage = isset($_POST['otherDamage']) ? $_POST['otherDamage'] : '';
    $contactNumber = $_POST['contactNumber'];
    $repairDate = $_POST['repairDate'];
    $aadharNumber = $_POST['aadharNumber'];

    // Validate the input 
    /*
    if (empty($carModel) || empty($damageType) || empty($contactNumber) || empty($repairDate) || empty($aadharNumber)) {
        echo "<script>alert('All fields are required.'); history.back();</script>";
        exit();
    }

    if (!preg_match('/^[6789]\d{9}$/', $contactNumber)) {
        echo "<script>alert('Contact number must be 10 digits starting with 6, 7, 8, or 9.'); history.back();</script>";
        exit();
    }

    if (!preg_match('/^\d{12}$/', $aadharNumber)) {
        echo "<script>alert('Aadhar number must be 12 digits.'); history.back();</script>";
        exit();
    } */

    // Store the repair booking details
    $firstName = $_SESSION['firstName'];
    $lastName = $_SESSION['lastName'];

    // Handle the optional file upload
    $photoPath = null;
    if (isset($_FILES['damagePhoto']) && $_FILES['damagePhoto']['error'] == 0) {
        $photoTmpName = $_FILES['damagePhoto']['tmp_name'];
        $photoName = $_FILES['damagePhoto']['name'];
        $photoSize = $_FILES['damagePhoto']['size'];
        $photoType = $_FILES['damagePhoto']['type'];
        $photoExtension = strtolower(pathinfo($photoName, PATHINFO_EXTENSION));

        // Allowed file types
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($photoExtension, $allowedExtensions)) {
            $newPhotoName = uniqid() . '.' . $photoExtension;
            $photoPath = 'uploads/' . $newPhotoName;

            // Move the file to the desired location
            if (!move_uploaded_file($photoTmpName, $photoPath)) {
                echo "<script>alert('Failed to upload photo.'); history.back();</script>";
                exit();
            }
        } else {
            echo "<script>alert('Invalid file type. Only JPG, JPEG, PNG, and GIF are allowed.'); history.back();</script>";
            exit();
        }
    }
    echo "<p>Photo path: $photoPath</p>";
    // Insert the booking details into the database
    $stmt = $conn->prepare("INSERT INTO repair_booking (firstName, lastName, carModel, damageType, otherDamage, contactNumber, repairDate, aadharNumber, photoPath) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssss", $firstName, $lastName, $carModel, $damageType, $otherDamage, $contactNumber, $repairDate, $aadharNumber, $photoPath);

    if ($stmt->execute()) {
        echo "<script>alert('Car repair booking applied successfully.'); window.location.href = 'homepage.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); history.back();</script>";
    }
}
?>
