<?php

include 'connect.php';
  
session_start();

// Check if the session variables for firstName and lastName are set
if (isset($_SESSION['firstName']) && isset($_SESSION['lastName'])) {
    $firstName = $_SESSION['firstName'];
    $lastName = $_SESSION['lastName'];

  

} else {
    // Handle the case where session variables are not set
    echo "
    <script>
    alert('Please Log In To Purchase');
    window.location.href='accessories.php';
    </script>
    ";
    exit();
}  

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $parts = $_POST["parts"];
  $price = $_POST["price"];
  $quantity = $_POST["quantity"];

  

  // Prepare the SQL statement
  $sql = "INSERT INTO cart (parts, price, quantity, firstName, lastName) VALUES (?, ?, ?, ?, ?)";
  $stmt = $conn->prepare($sql);

  // Bind parameters with correct data types (adjust as needed)
  $stmt->bind_param("ssdss", $parts, $price, $quantity, $firstName, $lastName);

  // Execute the statement
  $stmt->execute();

  // Handle potential errors
  if ($stmt->error) {
    echo "Error: " . $stmt->error;
  } else {
    echo "
  <script>
  alert('Product Added Sucessfully ');
  window.location.href='accessories.php';
  </script>
  ";
  }

  $stmt->close();
}

$conn->close();









?>