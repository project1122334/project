<?php 
session_start();
include('connect.php'); // include your database connection file

?>


<!doctype html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Contact Us Page - Tata Cars</title>
    <style>
        .banner {
            background: url(abt/images/bg_3.jpg);
            background-position: center;
            background-size: cover;
            height: 50vh;
        }
        .bg-new {
            background: transparent;
        }
        .bg-green {
            background-color: #03de1c;
        }
        .text-green {
            color: #03de1c;
        }
        .h1 {
            font-size: 65px;
            font-weight: 700;
        }
        .btn-green {
            background-color: #03de1c;
            width: 190px;
            height: 47px;
        }
        .logo img {
            width: 50px;
        }
        .contact {
            padding: 60px 0;
        }
        .contact .container {
            max-width: 800px;
            margin: 0 auto;
        }
        .contact h2 {
            font-size: 48px;
            margin-bottom: 30px;
            text-align: center;
            color: #333;
        }
        .contact-form {
            background: #f9f9f9;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        .contact-form .form-label {
            font-weight: bold;
            color: #555;
            font-size: 18px;
        }
        .contact-form input[type="text"],
        .contact-form input[type="email"],
        .contact-form textarea,
        .contact-form .form-check-input {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 18px;
        }
        .contact-form textarea {
            resize: vertical;
        }
        .contact-form button {
            background: #333;
            color: #fff;
            padding: 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            text-transform: uppercase;
            font-size: 18px;
            transition: background 0.3s ease;
        }
        .contact-form button:hover {
            background: #555;
        }
        .google-map .map-iframe {
            width: 100%;
            height: 400px;
            border: none;
        }
        .site-footer {
            background: #333;
            padding: 40px 0;
            color: #fff;
            text-align: center;
        }
        @media (max-width: 768px) {
            .contact-form .col-lg-6,
            .contact-form .col-lg-4,
            .contact-form .col-12 {
                width: 100%;
            }
            .site-footer .col-lg-3,
            .site-footer .col-6 {
                text-align: center;
                margin-top: 20px;
            }
        }
    </style>
</head>

<body>

    <div class="banner">
        <nav class="navbar navbar-expand-lg bg-new pt-4 px-3">
            <a class="logo" href="#"><img src="images/image.jpg" alt="..."></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon bg-green"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item mx-2 bg-green">
                        <a class="nav-link text-white" href="homepage.php">HOME</a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="#">Services</a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="accessories.php">Accessories</a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="#">New Item</a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="about.php">About</a>
                    </li>
                    <li class="nav-item mx-2">
                        <a class="nav-link text-white" href="#">Contact Us</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>

    <!-- Space between banner and contact form -->
    <div style="margin-top: 20px;"></div>

    <section class="contact section-padding" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-12 mx-auto">
                    <h2 class="mb-4 text-center" data-aos="fade-up">Don't be shy, write to us</h2>
                    <form action="#" method="post" class="contact-form" role="form" data-aos="fade-up">
                        <div class="row">
                            <div class="col-lg-6 col-6">
                                <label for="name" class="form-label">Name <sup class="text-danger">*</sup></label>
                                <input type="text" name="name" id="name" class="form-control" placeholder="Full name" required>
                            </div>
                            <div class="col-lg-6 col-6">
                                <label for="email" class="form-label">Email <sup class="text-danger">*</sup></label>
                                <input type="email" name="email" id="email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="Email address" required>
                            </div>
                            <div class="col-12 my-4">
                                <label for="message" class="form-label">How can we help?</label>
                                <textarea name="message" rows="6" class="form-control" id="message" placeholder="Tell us about the project" required></textarea>
                            </div>
                            <div class="col-12">
                                <label for="services" class="form-label">Services<sup class="text-danger">*</sup></label>
                            </div>
                            <div class="col-lg-4 col-12">
                                <div class="form-check">
                                    <input type="checkbox" id="checkbox1" name="checkbox1" class="form-check-input">
                                    <label class="form-check-label" for="checkbox1">Car Related</label>
                                </div>
                            </div>
                            <div class="col-lg-4 col-12 my-2 my-lg-0">
                                <div class="form-check">
                                    <input type="checkbox" id="checkbox2" name="checkbox2" class="form-check-input">
                                    <label class="form-check-label" for="checkbox2">Finalcial</label>
                                </div>
                            </div>
                            <div class="col-lg-4 col-12">
                                <div class="form-check">
                                    <input type="checkbox" id="checkbox3" name="checkbox3" class="form-check-input">
                                    <label class="form-check-label" for="checkbox3">Service Issue</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5 col-12 mx-auto mt-5">
                            <button type="submit" class="form-control">Send Message</button>
                        </div>
                    </form>
                    <?php

// Check if the session variables for firstName and lastName are set
if (isset($_SESSION['firstName']) && isset($_SESSION['lastName'])) {
    $firstName = $_SESSION['firstName'];
    $lastName = $_SESSION['lastName'];
} else {
    // If the user is not logged in, set default values for firstName and lastName
    $firstName = "New";
    $lastName = "User";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    $services = [];

    // Check which checkboxes were selected
    if (isset($_POST['checkbox1'])) {
        $services[] = 'Car Related';
    }
    if (isset($_POST['checkbox2'])) {
        $services[] = 'Financial';
    }
    if (isset($_POST['checkbox3'])) {
        $services[] = 'Service Issue';
    }
    
    // Convert services array to a comma-separated string
    $services_selected = implode(', ', $services);

    // Insert contact form submission into the database
    $sql = "INSERT INTO contact (name, email, message, services, firstName, lastName) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $name, $email, $message, $services_selected, $firstName, $lastName);

    if ($stmt->execute()) {
        echo"<script>
        alert('Message sent successfully!');
        window.location.href = 'contact.php';
      </script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>


                </div>
            </div>
        </div>
    </section>

    <section class="google-map">
        <iframe src="https://maps.google.com/maps?q=Maharshi%20Gurukul,Ranekpar%20Road,Halvad,Gujarat&t=&z=13&ie=UTF8&iwloc=&output=embed" class="map-iframe" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </section>

 <!-- Footer Start -->
 <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
					<h5 class="text-white mb-4">Our Work Place</h5>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Maharshi Gurukul,Ranekpar Road,Halvad,Gujarat</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>8200249640</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>6351771401</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>tatacars770@gmail.com</p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Quick Links</h5>
                        <a class="btn btn-link text-white-50" href="">Services</a>
                        <a class="btn btn-link text-white-50" href="accessories.php">Accessories</a>
                        <a class="btn btn-link text-white-50" href="">New Item</a>
                        <a class="btn btn-link text-white-50" href="">About Us</a>
                        <a class="btn btn-link text-white-50" href="">Contact Us</a>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Photo Gallery</h5>
                        <div class="row g-2 pt-2">
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/punch.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/safari.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/nexon.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/harrier.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/happy.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/service.jpg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Newsletter</h5>
                        <p>
"Drive the Future with Tata: Innovation, Reliability, Excellence."</p>
                        <div class="position-relative mx-auto" style="max-width: 400px;">
                           
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="">Home</a>
                                <a href="">Cookies</a>
                                <a href="">Help</a>
                                <a href="">FQAs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->

		<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>


    
    <!-- Footer End -->

</body>
</html>
