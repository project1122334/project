<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>


.white-box {
    background-color: white;
    border: 1px solid black;
    padding: 20px;
    width: 60%;
    margin: 20px auto 0 auto;
}


.smaller-heading {
    font-size: 18px;
}

.custom-button {
    background-color: rgb(125, 125, 235);
}
.fa-envelope {
    font-size: 24px;
}
.fa-envelope {
    color: blue;
}
body {
    background-image: url("images/image.jpg");
    background-size: cover; /* Scales image to cover the entire body */
    background-repeat: no-repeat; /* Prevents image repetition */
    background-position: center; /* Centers the image */
    min-height: 100vh; /* Ensures the image fills the entire viewport height */
  }
  .btn{
    font-size:1.1rem;
    padding:8px 0;
    border-radius:5px;
    outline:none;
    border:none;
    width:100%;
    background:rgb(125,125,235);
    color:white;
    cursor:pointer;
    transition:0.9s;
}

  </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="white-box">
                    <h2 class="text-center mb-4 smaller-heading">Forgot Password</h2>
                    <form method="POST" action="forgotpassword.php"> <div class="mb-3">
                            <label for="email" class="form-label">Enter Your Email</label>
                            <style>
                                input::-webkit-input-placeholder {
                                    border-bottom: 1px solid #757575;
                                }
                            </style>
                            <input type="email" class="form-control" id="email" name="email" placeholder="email">
                        </div>
                        <button type="submit" class="btn custom-button" name="send-reset-link">Send Email</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
                           
                            
</body>
</html>
