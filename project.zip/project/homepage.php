<?php

session_start();
include ("connect.php");


// Fetch profile photo from the database
$userId = isset($_SESSION['id']) ? $_SESSION['id'] : null;
if ($userId) {
    $stmt = $conn->prepare("SELECT profile_photo FROM users WHERE id = ?");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stmt->bind_result($profilePhoto);
    $stmt->fetch();
    $stmt->close();
    $_SESSION['profilePhoto'] = $profilePhoto; // Store in session if needed
}
?>


<!DOCTYPE html>
<html lang="en">
<head><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <style>
    .card {
      margin: 20px;
      border-radius: 15px; /* Adjust this value for the desired roundness */
      overflow: hidden; /* Ensures that the content doesn't overflow the rounded corners */
    }
    .card-img-top {
      width: 100%;
      height: auto; /* Maintain aspect ratio */
      border-bottom-left-radius: 15px; /* Same radius as the card for the bottom corners */
      border-bottom-right-radius: 15px; /* Same radius as the card for the bottom corners */
    }
    .logo img {
      width: 50px;
    }
  </style>

<style>
.banner{background: url(images/avinya.jpg); background-position: center; background-size: cover;height: 100vh;}
.bg-new{background: transparent;}
.bg-green{background-color: #03de1c;}
.text-green{color: #03de1c;}
.h1{
  font-size: 65px; font-weight: 700;}
.btn-green{background-color: #03de1c; width: 190px; height: 47px;}



.featured-cars{
    padding:112px 0 120px;
}
.featured-cars-content{padding-top:96px;}

/*.single-featured-cars*/
.featured-img-box {
    border: 1px solid #dadfe9;
}
.featured-cars-img {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 30px;
    height: 220px;
    border-bottom: 1px solid #dadfe9;
}
.featured-model-info{padding:12px 7px;}
.featured-model-info p {
    font-size: 12px;
    color: #8c92a0;
    text-transform: capitalize;
}
.featured-mi-span{display: inline-block;margin:0 10px;}
.featured-hp-span{display: inline-block;margin-right: 10px;}
.featured-cars-txt{margin:21px 0 47px;}
.featured-cars-txt h2 a{font-size: 16px;margin-bottom: 15px;}
.featured-cars-txt h2 a span{text-transform: uppercase;}
.featured-cars-txt h3{margin-bottom: 10px;}
.featured-cars-txt h3,.featured-cars-txt p{font-size: 13px;}
/*.single-featured-cars*/


/*** Footer ***/
.footer .btn.btn-social {
    margin-right: 5px;
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--light);
    border: 1px solid rgba(255,255,255,0.5);
    border-radius: 35px;
    transition: .3s;
}

.footer .btn.btn-social:hover {
    color: var(--primary);
    border-color: var(--light);
}

.footer .btn.btn-link {
    display: block;
    margin-bottom: 5px;
    padding: 0;
    text-align: left;
    font-size: 15px;
    font-weight: normal;
    text-transform: capitalize;
    transition: .3s;
}

.footer .btn.btn-link::before {
    position: relative;
    content: "\f105";
    font-family: "Font Awesome 5 Free";
    font-weight: 900;
    margin-right: 10px;
}

.footer .btn.btn-link:hover {
    letter-spacing: 1px;
    box-shadow: none;
}

.footer .form-control {
    border-color: rgba(255,255,255,0.5);
}

.footer .copyright {
    padding: 25px 0;
    font-size: 15px;
    border-top: 1px solid rgba(256, 256, 256, .1);
}

.footer .copyright a {
    color: var(--light);
}

.footer .footer-menu a {
    margin-right: 15px;
    padding-right: 15px;
    border-right: 1px solid rgba(255, 255, 255, .1);
}

.footer .footer-menu a:last-child {
    margin-right: 0;
    padding-right: 0;
    border-right: none;
}
/* Dropdown Menu */
.dropdown-menu {
  min-width: 300px; /* Doubled the size of the dropdown box */
  min-height: 250px;
  padding: 20px; /* Increased padding to match the new size */
  background-color: #17a2b8; /* Info color from Bootstrap */
  border:3px solid #000;
  border-radius: 8px;
}

/* Profile Image */
.dropdown-menu img {
  border-radius: 100%;
  width: 200px; /* Increased profile image size */
  height: 100px; /* Increased profile image size */
  border: 3px solid #03de1c; /* Green border */
}

/* Profile Text */
.dropdown-menu p {
  margin: 0;
  font-size: 16px; /* Slightly larger font */
  color: #fff; /* White text for contrast */
}

/* Profile Placeholder Styling */
.profile-placeholder {
  width: 100px;
  height: 100px;
  border: 3px solid #28a745; /* Green border */
  border-radius: 50%; /* Circle shape */
  background-color: #fff; /* White background */
  color: #000; /* Black text */
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: bold;
}


.navbar-nav .dropdown-toggle {
  background-color: #03de1c; /* Green background for profile button */
  color: #fff;
  padding: 10px;
  border-radius: 5px;
}




</style>
</head>
<body>
<div class="banner">
<!--Navbar -->
<nav class="navbar navbar-expand-lg bg-new pt-4 px-3">
  <a class="logo" href="#"><img src="images/image.jpg" alt="..."></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon bg-green"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
      <li class="nav-item mx-2 bg-green">
        <a class="nav-link text-white" href="#">HOME</a>
      </li>
      
     
      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="services.php">Services</a>
      </li>

      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="accessories.php">Accessories</a>
      </li>

      
      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="about.php">About</a>
      </li>

     
      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="contact.php">Contact Us</a>
      </li>
       
          
  
      <?php if (isset($_SESSION['firstName']) && isset($_SESSION['lastName'])): ?>
            <li class="nav-item mx-2">
              <a class="nav-link text-white" href="logout.php">Logout</a>
            </li>

            <li class="nav-item dropdown mx-2">
    <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
      Profile
    </a>
    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
      <li>
        <div class="p-3 text-center">
        <h1>Welcome, <?php echo $_SESSION['firstName']; ?></h1>
            <!-- Profile Picture -->
          

            <?php if (!isset($_SESSION['profilePhoto']) || empty($_SESSION['profilePhoto'])): ?>
            <div class="profile-placeholder" style="width: 100px; height: 100px; border: 3px solid #28a745; border-radius: 50%; background-color: #fff; color: #000; display: flex; align-items: center; justify-content: center;">
            <form action="submenu/upload.php" method="post" enctype="multipart/form-data">
                  <input type="file" name="profile_photo" accept="image/*" required>
                  <button type="submit">Upload Photo</button>
                  </form>

            </div>
          <?php else: ?>   
          <?php
          // Convert the profile photo path to a web-friendly URL
     
          $webPath = str_replace($_SERVER['DOCUMENT_ROOT'], '', $_SESSION['profilePhoto']);
          ?>
          <img src="uploads/<?php echo htmlspecialchars($webPath); ?>" alt="Profile Photo" class="img-fluid rounded-circle" style="width: 100px; height: 100px; border: 3px solid #000;">
     <?php endif; ?>
          <div class="mt-3">
            <!-- First Name, Last Name, Email -->


                          <!-- Profile Info Display -->
                    <div class="profile-info">
                     <p><strong>First Name:</strong> 
                     <?php echo isset($_SESSION['firstName']) ? $_SESSION['firstName'] : 'Not LoggedIn'; ?>
                    </p>
                   <p><strong>Last Name:</strong> 
                    <?php echo isset($_SESSION['lastName']) ? $_SESSION['lastName'] : 'Guest'; ?>
                     </p>
                     <p><strong>Email:</strong> 
                     <?php echo isset($_SESSION['email']) ? $_SESSION['email'] : 'Guest'; ?>
                     </p>
                     </div>
                     
    </div>
        </div>
      </li>
    </ul>
  </li>
</ul>


          <?php else: ?>
            <li class="nav-item mx-2">
              <a class="nav-link text-white" href="login.php">Login</a>
            </li>
          <?php endif; ?>

         
     

  </div>
</nav>
<!--Navbar End -->

<!--page -->
  <div class="container-fluid" style="margin-top: 5px;">
     <div class="row">
       <div clas="col-md-12 text-white" style="padding-left: 12%;">
       <h1 style="color: white;">WELCOME<br>TO OUR<br>WEBSITE</h1>
       <a href="book.php">
       <button class="btn btn-green text-white rounded-0 mt-5" style="font-size: 22px;">BOOK NOW</button>
       </a>
       </div>
     </div>
   </div>    
<!--Page End -->
</div>


<div id="carouselExampleCaptions" class="carousel slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
    
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/harrier.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/punch.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/safari.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>

  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<?php                     //******this is code for card *********   ?>

<div class="row row-cols-1 row-cols-md-2 g-4">
  <div class="col">
    <div class="card">
    <div class="card border border-dark">
      <video class="card-img-top" controls loop autoplay muted>
      <source src="images/video.mp4" type="video/mp4">
      Your browser does not support the video tag.
    </video>
      <div class="card-body">
        <h5 class="card-title">Curve</h5>
        <p class="card-text">Our New Tata Curve Is Out</p>
      </div>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
    <div class="card border border-dark">
      <img src="images/service.jpg" class="card-img-top" alt="..." >
      <div class="card-body">
        <h5 class="card-title">Services</h5>
        <p class="card-text">No Compromise With The Services Here At Tata Cars Best And Fast Service,Your Needs Our Priority</p>
      </div>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
    <div class="card border border-dark">
      <img src="images/customer.jpg" class="card-img-top" alt="card image cap">
      <div class="card-body">
        <h5 class="card-title">Customer Care</h5>
        <p class="card-text">Customer's Problem Is Ours To We Take Your Complaint Seriously And Do Take Further Action ,Here To Help,Always</p>
      </div>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
    <div class="card border border-dark">
      <img src="images/engine.jpg" class="card-img-top" alt="card image cap" style="width: 600px; height: 360px;">
      <div class="card-body">
        <h5 class="card-title">Reliable engine</h5>
        <p class="card-text">Durable And Reliable Made For The Long Run ,Strong And Steady</p>
      </div>
      </div>
    </div>
  </div>
</div>
<?php //            ************code for list************   ?>




<!--featured-cars start -->
<section id="featured-cars" class="featured-cars">
			<div class="container">
				<div class="section-header">
					<p style="text-align: center;">checkout <span>the</span> featured cars</p>
					<h2 style="text-align: center; text-decoration: underline; text-decoration-color: green; text-decoration-thickness: 2px">featured cars</h2>
				</div><!--/.section-header-->
				<div class="featured-cars-content">
					<div class="row">
						<div class="col-lg-3 col-md-4 col-sm-6">
							<div class="single-featured-cars">
								<div class="featured-img-box">
									<div class="featured-cars-img">
										<img src="images/cars/curve.png" alt="...">
									</div>
									<div class="featured-model-info">
										<p>
											model: 2024
											<span class="featured-mi-span"> 520 km/Charge</span> 
											<span class="featured-hp-span"> 166HP</span>
											 automatic
										</p>
									</div>
								</div>
								<div class="featured-cars-txt">
									<h2><a href="#">Tata Curve <span>EV</span></a></h2>
									<h3>₹21.99/Lakh</h3>
									<p>
										Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non. 
									</p>
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6">
							<div class="single-featured-cars">
								<div class="featured-img-box">
									<div class="featured-cars-img">
										<img src="images/cars/safari.png" alt="cars">
									</div>
									<div class="featured-model-info">
										<p>
											model: 2023
											<span class="featured-mi-span"> 14KM/L</span> 
											<span class="featured-hp-span"> 170HP</span>
											 automatic/manual
										</p>
									</div>
								</div>
								<div class="featured-cars-txt">
									<h2><a href="#">Tata Safari <span></span></a></h2>
									<h3>₹25.99/Lakh</h3>
									<p>
										Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non. 
									</p>
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6">
							<div class="single-featured-cars">
								<div class="featured-img-box">
									<div class="featured-cars-img">
										<img src="images/cars/kite.jpg" alt="cars">
									</div>
									<div class="featured-model-info">
										<p>
											model: 2016
											<span class="featured-mi-span"> 25KM/L</span> 
											<span class="featured-hp-span"> 67HP</span>
											 Manual
										</p>
									</div>
								</div>
								<div class="featured-cars-txt">
									<h2><a href="#">Tata Kite <span></span></a></h2>
									<h3>₹6.99/Lakh</h3>
									<p>
										Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non. 
									</p>
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6">
							<div class="single-featured-cars">
								<div class="featured-img-box">
									<div class="featured-cars-img">
										<img src="images/cars/nexonev.jpg" alt="cars">
									</div>
									<div class="featured-model-info">
										<p>
											model: 2022
											<span class="featured-mi-span"> 312KM/Charge</span> 
											<span class="featured-hp-span"> 170HP</span>
											 automatic
										</p>
									</div>
								</div>
								<div class="featured-cars-txt">
									<h2><a href="#">Tata Nexon <span>EV</span> </a></h2>
									<h3>₹15.50/Lakh</h3>
									<p>
										Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non. 
									</p>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-3 col-md-4 col-sm-6">
							<div class="single-featured-cars">
								<div class="featured-img-box">
									<div class="featured-cars-img">
										<img src="images/cars/nexon.png" alt="cars">
									</div>
									<div class="featured-model-info">
										<p>
											model: 2022
											<span class="featured-mi-span"> 19KM/L</span> 
											<span class="featured-hp-span"> 110HP</span>
											 Automatic/Manual
										</p>
									</div>
								</div>
								<div class="featured-cars-txt">
									<h2><a href="#">Tata Nexon <span></span></a></h2>
									<h3>₹8.00/Lakh</h3>
									<p>
										Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non. 
									</p>
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6">
							<div class="single-featured-cars">
								<div class="featured-img-box">
									<div class="featured-cars-img">
										<img src="images/cars/tiago.png" alt="cars">
									</div>
									<div class="featured-model-info">
										<p>
											model: 2016
											<span class="featured-mi-span"> 20KM/L</span> 
											<span class="featured-hp-span"> 86HP</span>
											 Manual
										</p>
									</div>
								</div>
								<div class="featured-cars-txt">
									<h2><a href="#">Tata Tiago <span></span> </a></h2>
									<h3>₹8.99/Lakh</h3>
									<p>
										Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non. 
									</p>
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6">
							<div class="single-featured-cars">
								<div class="featured-img-box">
									<div class="featured-cars-img">
										<img src="images/cars/hexa.jpg" alt="cars">
									</div>
									<div class="featured-model-info">
										<p>
											model: 2017
											<span class="featured-mi-span"> 20KM/L</span> 
											<span class="featured-hp-span"> 160HP</span>
											 Manual
										</p>
									</div>
								</div>
								<div class="featured-cars-txt">
									<h2><a href="#"><span>Tata Hexa</span></a></h2>
									<h3>₹19.90/Lakh</h3>
									<p>
										Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non. 
									</p>
								</div>
							</div>
						</div>
						<div class="col-lg-3 col-md-4 col-sm-6">
							<div class="single-featured-cars">
								<div class="featured-img-box">
									<div class="featured-cars-img">
										<img src="images/cars/harrier.png" alt="cars">
									</div>
									<div class="featured-model-info">
										<p>
											model: 2019
											<span class="featured-mi-span"> 16KM/L</span> 
											<span class="featured-hp-span"> 170HP</span>
											 Automatic/Manual
										</p>
									</div>
								</div>
								<div class="featured-cars-txt">
									<h2><a href="#">Tata Harrier<span></span></a></h2>
									<h3>₹25.00/Lakh</h3>
									<p>
										Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non. 
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div><!--/.container-->

		</section><!--/.featured-cars-->
		<!--featured-cars end -->

 <!-- Footer Start -->
 <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
					<h5 class="text-white mb-4">Our Work Place</h5>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Maharshi Gurukul,Ranekpar Road,Halvad,Gujarat</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>8200249640</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>6351771401</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>tatacars770@gmail.com</p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Quick Links</h5>
                        <a class="btn btn-link text-white-50" href="">Services</a>
                        <a class="btn btn-link text-white-50" href="accessories.php">Accessories</a>
                        <a class="btn btn-link text-white-50" href="">New Item</a>
                        <a class="btn btn-link text-white-50" href="about.php">About Us</a>
                        <a class="btn btn-link text-white-50" href="contact.php">Contact Us</a>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Photo Gallery</h5>
                        <div class="row g-2 pt-2">
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/punch.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/safari.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/nexon.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/harrier.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/happy.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/service.jpg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Newsletter</h5>
                        <p>
"Drive the Future with Tata: Innovation, Reliability, Excellence."</p>
                        <div class="position-relative mx-auto" style="max-width: 400px;">
                           
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="">Home</a>
                                <a href="">Cookies</a>
                                <a href="">Help</a>
                                <a href="">FQAs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->

		<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>




      <div style="text-align:center; padding:15%;">
      <p  style="font-size:50px; font-weight:bold;">
        <?php 
       if(isset($_SESSION['email'])){
        $email=$_SESSION['email'];
        $query=mysqli_query($conn, "SELECT users.* FROM users WHERE users.email='$email'");
        while($row=mysqli_fetch_array($query)){
           // echo $row['firstName'].' '.$row['lastName'];
        }
       }
       ?>
     </p>
      
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>

</html>


