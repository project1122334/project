-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 08, 2024 at 07:07 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`email`, `password`) VALUES
('admin@gmail.com', '1111');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `parts` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `parts`, `price`, `quantity`, `firstName`, `lastName`) VALUES
(8, 'oil', '1000.00', 3, 'jiya', 'jiya'),
(9, 'battry', '7000.00', 1, 'jiya', 'jiya'),
(10, 'water_pump', '9500.00', 1, 'jiya', 'jiya'),
(11, 'fuel_injector', '10000.00', 1, 'jiya', 'jiya'),
(12, 'fuel_injector', '10000.00', 2, 'jiya', 'jiya'),
(13, 'fuel_injector', '10000.00', 1, 'jiya', 'jiya'),
(53, 'Oil', '1000.00', 1, 'aaa', 'aaa'),
(70, 'Tyre', '15000.00', 1, 'anil', 'mori'),
(71, 'Battry', '7000.00', 3, 'anil', 'mori'),
(72, 'Oil', '1000.00', 1, 'fsdsdfdsfsdf', 'fsgtytjhntyjt'),
(80, 'Oil', '1000.00', 1, 'sumit', 'parmar'),
(81, 'Oil', '1000.00', 1, 'sumit', 'parmar'),
(82, 'Fuel_Injector', '10000.00', 2, 'sumit', 'parmar'),
(83, 'Fuel_Injector', '10000.00', 1, 'sumit', 'parmar'),
(84, 'Oil', '1000.00', 1, 'anil', 'mori'),
(85, 'Battry', '7000.00', 1, 'anil', 'mori'),
(86, 'Battry', '7000.00', 1, 'sumit', 'parmar');

-- --------------------------------------------------------

--
-- Table structure for table `car_bookings`
--

CREATE TABLE `car_bookings` (
  `id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `carModel` varchar(50) NOT NULL,
  `bookingDate` date NOT NULL,
  `contactNumber` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `carColor` varchar(20) NOT NULL,
  `paymentType` enum('loan','fullPayment') NOT NULL,
  `insuranceType` enum('collisionDamage','theftProtection','liabilityInsurance','personalAccidentInsurance') NOT NULL,
  `aadharNumber` char(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `car_bookings`
--

INSERT INTO `car_bookings` (`id`, `firstName`, `lastName`, `carModel`, `bookingDate`, `contactNumber`, `address`, `carColor`, `paymentType`, `insuranceType`, `aadharNumber`) VALUES
(2, 'jiya', 'jiya', 'punch', '2024-08-05', '9999999999', 'hjhgjg', 'purple', 'fullPayment', 'liabilityInsurance', '556677889900'),
(5, 'sumit', 'parmar', 'punch', '2024-08-13', '8666666666', 'tgdgfdd', 'orange', 'fullPayment', 'theftProtection', '345678899955'),
(6, 'sumit', 'parmar', 'nexonEv', '2024-08-21', '9999999999', 'sdsdasdasas', 'yellow', 'fullPayment', 'liabilityInsurance', '345678899955'),
(7, 'sumit', 'parmar', 'nexonEv', '2024-08-05', '6351771401', 'dfssdtgdfghdfh', 'yellow', 'loan', 'theftProtection', '434667890876'),
(10, 'anil', 'mori', 'punch', '2024-08-13', '7777777777', 'yhujghj', 'yellow', 'fullPayment', 'collisionDamage', '345678899955');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `services` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `message`, `services`, `firstName`, `lastName`, `created_at`) VALUES
(3, 'sumit', 'sumitparmar938@gmail.com', 'good it is', 'Car Related, Financial', 'sumit', 'parmar', '2024-09-03 18:53:57'),
(5, 'anil mori', 'anilmori@gmail.com', 'it was good i enjoyed your site i like the features', 'Car Related', 'anil', 'mori', '2024-09-04 13:58:23');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `receiver_id` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('sent','delivered','seen') DEFAULT 'sent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `image`) VALUES
(4, 'motor', '434.00', 'gsdfgf', '../images/avinyaa.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `repair_booking`
--

CREATE TABLE `repair_booking` (
  `id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `carModel` varchar(50) NOT NULL,
  `damageType` varchar(50) NOT NULL,
  `otherDamage` text DEFAULT NULL,
  `contactNumber` varchar(10) NOT NULL,
  `repairDate` date NOT NULL,
  `aadharNumber` varchar(12) NOT NULL,
  `photoPath` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `repair_booking`
--

INSERT INTO `repair_booking` (`id`, `firstName`, `lastName`, `carModel`, `damageType`, `otherDamage`, `contactNumber`, `repairDate`, `aadharNumber`, `photoPath`) VALUES
(8, 'anil', 'mori', 'nexon', 'wiring_problem', 'hello', '9999999999', '2024-07-29', '434667890876', NULL),
(9, 'anil', 'mori', 'tataa', 'wiring_problem', 'hello', '7666666666', '2024-08-07', '556677889900', NULL),
(10, 'fsdsdfdsfsdf', 'fsgtytjhntyjt', 'tataa', 'wiring_problem', 'dfasdasdasdas', '6351771401', '2024-08-20', '556677889900', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `test_bookings`
--

CREATE TABLE `test_bookings` (
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `id` int(11) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `phoneNumber` varchar(10) NOT NULL,
  `carModel` varchar(255) NOT NULL,
  `testDriveDate` date NOT NULL,
  `testDriveTime` time NOT NULL,
  `pickupLocation` varchar(255) NOT NULL,
  `customLocation` varchar(255) DEFAULT NULL,
  `aadharCard` varchar(12) NOT NULL,
  `transmissionType` varchar(50) NOT NULL,
  `fuelType` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `test_bookings`
--

INSERT INTO `test_bookings` (`firstName`, `lastName`, `id`, `fullName`, `phoneNumber`, `carModel`, `testDriveDate`, `testDriveTime`, `pickupLocation`, `customLocation`, `aadharCard`, `transmissionType`, `fuelType`) VALUES
('anil', 'mori', 4, 'sumitasdasasa', '9999999999', 'Hexa', '2024-08-03', '17:42:00', 'Enter Location', 'fdsfsdfdsfsd', '123456789000', 'Manual', 'CNG'),
('anil', 'mori', 5, 'sasasasas', '9999999999', 'Tiago', '2024-08-20', '17:41:00', 'At Showroom', '', '123456789000', 'Manual', 'Diesel'),
('sumit', 'parmar', 8, 'eeeeeee', '6351771401', 'Harrier', '2024-09-22', '22:39:00', 'At Showroom', '', '123456789000', 'Manual', 'Petrol');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `resettoken` varchar(255) DEFAULT NULL,
  `resettokenexpire` date DEFAULT NULL,
  `profile_photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstName`, `lastName`, `email`, `password`, `resettoken`, `resettokenexpire`, `profile_photo`) VALUES
(1, 'sumit', 'parmar', 'sumitparmar938@gmail.com', 'b59c67bf196a4758191e42f76670ceba', NULL, NULL, '../uploads/person_1.jpg'),
(3, 'a', 'b', 'aaa12@gmail.com', 'b59c67bf196a4758191e42f76670ceba', NULL, NULL, NULL),
(4, 'brijesh', 'kanzariya', 'bg123@gmail.com', '1bbd886460827015e5d605ed44252251', NULL, NULL, '../uploads/avinyaa.jpg'),
(5, 'aaa', 'aaa', 'qqq12@gmail.com', '1bbd886460827015e5d605ed44252251', NULL, NULL, NULL),
(14, 'me', 'meme', 'me@gmail.com', 'b59c67bf196a4758191e42f76670ceba', NULL, NULL, NULL),
(17, 'dsdasdsda', 'sadsdadas', 'j@gmail.com', 'b59c67bf196a4758191e42f76670ceba', NULL, NULL, NULL),
(18, 'jiya', 'jiya', 'jiya@gmail.com', 'b59c67bf196a4758191e42f76670ceba', NULL, NULL, NULL),
(19, 'anil', 'mori', 'anilmori@gmail.com', 'b59c67bf196a4758191e42f76670ceba', NULL, NULL, '../uploads/person_2.jpg'),
(20, 'fsdsdfdsfsdf', 'fsgtytjhntyjt', 'abcdefg@gmail.com', 'b59c67bf196a4758191e42f76670ceba', NULL, NULL, NULL),
(21, 'harshad', 'k', 'harshadkanzariya62@gmail.com', 'b59c67bf196a4758191e42f76670ceba', '3a1d40cac3899777524665f943299273', '2024-09-04', '../uploads/person_4.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `car_bookings`
--
ALTER TABLE `car_bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repair_booking`
--
ALTER TABLE `repair_booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_bookings`
--
ALTER TABLE `test_bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `car_bookings`
--
ALTER TABLE `car_bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `repair_booking`
--
ALTER TABLE `repair_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `test_bookings`
--
ALTER TABLE `test_bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
