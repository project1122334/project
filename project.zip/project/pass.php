<?php 
/*secret123@#
dyoz ugyy obto rorm
dyoz ugyy obto rorm
dyoz ugyy obto rorm
dyoz ugyy obto rorm

require ('forgotpassword.php');
sendMail($_POST['email'],$reset_token);



     
<form method='POST'>
         <h3>Create New Password</h3>
         <input type='password' placeholder='New Password' name='password'>
         <button type='submit' name='updatepassword'>UPDATE</button>
         <input type='hidden' name='email' value='$_GET[email]'>
         </form>
         ;   
  */
  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bootstrap Sidebar with About Box</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            height: 100vh;
            width: 300px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
            background-color: rgb(125, 125, 235); /* Custom color */
            color: #fff;
            padding-top: 20px;
            padding-left: 15px;
            padding-right: 15px;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
            transition: background-color 0.3s ease;
        }
        .sidebar a:hover {
            background-color: rgba(125, 125, 235, 0.8); /* Slightly transparent version on hover */
        }
        .about-box {
            background-color: #f8f9fa; /* Light grey background */
            color: #333; /* Dark text color */
            border: 1px solid #ddd; /* Light grey border */
            border-radius: 8px; /* Rounded corners */
            padding: 15px;
            margin-bottom: 20px;
        }
        .about-box h4 {
            margin-top: 0;
            margin-bottom: 10px;
            font-size: 1.2rem;
        }
        .about-box p {
            margin: 0;
            font-size: 0.9rem;
            color: #555;
        }
        .content {
            margin-left: 300px;
            padding: 20px;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="about-box">
            <h4>About Me</h4>
            <p>Hi, I'm John Doe, a passionate web developer with a knack for creating user-friendly applications.</p>
        </div>
        <a href="#home">Home</a>
        <a href="#about">About</a>
        <a href="#services">Services</a>
        <a href="#contact">Contact</a>
        <a href="#settings">Settings</a>
    </div>

    <!-- Content -->
    <div class="content">
        <h1>Main Content Area</h1>
        <p>This is the main content area. The sidebar is fixed on the left side of the page and remains visible as you scroll down the content.</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    </div>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>

  
  
  
  ?>

