<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services Page</title>
    <style>


.banner{background: url(images/parts.png); background-position: center; background-size: cover;height: 50vh;}
.bg-new{background: transparent;}
.bg-green{background-color: #03de1c;}
.text-green{color: #03de1c;}
.h1{
  font-size: 65px; font-weight: 700;}
.btn-green{background-color: #03de1c; width: 190px; height: 47px;}

.logo img {
      width: 50px;
    }

        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background: url('images/services/back2.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
            color: #333;
        }

        .services-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        /* Service Item Styles */
        .service-item {
            background-color: rgba(255, 255, 255, 0.8);
            margin-bottom: 40px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        .service-item h2 {
            color: #0056b3;
        }

        .service-item p {
            color: #555;
            font-size: 16px;
            margin-top: 10px;
        }

        /* Image Layout Styles */
        .service-images {
            display: flex;
            flex-direction: column;
            margin-bottom: 60px;
        }

        .first-image {
            display: flex;
            align-items: center;
        }

        .green-box {
            background-color: #A6D785; /* Lighter green background */
            padding: 30px;
            width: auto; /* Automatically adjust width */
            position: relative;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 25px;
        }

        .green-box img {
            width: 620px; /* Image size remains the same */
            height: auto;
            border-radius: 10px;
        }

        .green-box .description {
            color: white; /* Change text color to white */
            margin-left: 20px;
            font-size: 20px;
           
            max-width: 350px;
        }

        .btn-green {
            background-color: #03de1c;
            color: white;
            width: 190px;
            height: 47px;
            font-size: 22px;
            border: none;
            margin-top: 20px;
            cursor: pointer;
        }

        .second-image {
            margin-top: 30px; /* Start the blue box after the green box finishes */
            display: flex;
            justify-content: flex-end;
            margin-left: 3cm; /* Increase distance from the left side */
        }

        .blue-box {
            background-color: #17a2b8; /* Info color */
            padding: 30px;
            display: inline-block;
            border-radius: 15px;
        }

        .blue-box img {
            width: 450px; /* Increased image size */
            height: auto;
            border-radius: 10px;
        }

        /* Media Queries for Responsiveness */
        @media (max-width: 768px) {
            .service-images {
                flex-direction: column;
                position: static;
            }

            .first-image, .second-image {
                position: static;
            }

            .green-box img, .blue-box img {
                width: 100%;
            }

            .second-image {
                margin-top: 20px;
            }
        }


/*** Footer ***/
.footer .btn.btn-social {
    margin-right: 5px;
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--light);
    border: 1px solid rgba(255,255,255,0.5);
    border-radius: 35px;
    transition: .3s;
}

.footer .btn.btn-social:hover {
    color: var(--primary);
    border-color: var(--light);
}

.footer .btn.btn-link {
    display: block;
    margin-bottom: 5px;
    padding: 0;
    text-align: left;
    font-size: 15px;
    font-weight: normal;
    text-transform: capitalize;
    transition: .3s;
}

.footer .btn.btn-link::before {
    position: relative;
    content: "\f105";
    font-family: "Font Awesome 5 Free";
    font-weight: 900;
    margin-right: 10px;
}

.footer .btn.btn-link:hover {
    letter-spacing: 1px;
    box-shadow: none;
}

.footer .form-control {
    border-color: rgba(255,255,255,0.5);
}

.footer .copyright {
    padding: 25px 0;
    font-size: 15px;
    border-top: 1px solid rgba(256, 256, 256, .1);
}

.footer .copyright a {
    color: var(--light);
}

.footer .footer-menu a {
    margin-right: 15px;
    padding-right: 15px;
    border-right: 1px solid rgba(255, 255, 255, .1);
}

.footer .footer-menu a:last-child {
    margin-right: 0;
    padding-right: 0;
    border-right: none;
}





    </style>
</head>
<body>

<div class="banner">
<nav class="navbar navbar-expand-lg bg-new pt-4 px-3">
  <a class="logo" href="#"><img src="images/image.jpg" alt="..."></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon bg-green"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
      <li class="nav-item mx-2 bg-green">
        <a class="nav-link text-white" href="homepage.php">HOME</a>
      </li>
      
     
      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="#">Services</a>
      </li>

      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="#">Accessories</a>
      </li>

      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="#">New Item</a>
      </li>

      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="#">About</a>
      </li>

     
      <li class="nav-item mx-2">
        <a class="nav-link text-white" href="#">Contact Us</a>
      </li>

         
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
      <li class="nav-item mx-2 bg-green">
        <a class="nav-link text-red" style="font-size: 18px;" href="mycart.php">My Cart</a>
      </li>

  </div>
</nav>

<!--page -->
<div class="container-fluid" style="margin-top: 5px;">
     <div class="row">
       <div clas="col-md-12 text-white" style="padding-left: 12%;">
       <h1 style="color: white;">SHOP NOW<br>WITH<br>TATA CARS</h1>
   
       </div>
     </div>
   </div>    
<!--Page End -->

</div>





    <div class="services-container">
        <h1>Our Services</h1>

        <!-- Car Sales & Consultation -->
        <div class="service-item">
            <h2>Car Sales & Consultation</h2>
            <div class="service-images">
                <div class="first-image">
                    <div class="green-box">
                        <img src="images/services/sales.jpg" alt="Car Sales">
                        <div class="description">
                        As a Tata Motors car sales and consultation expert, I'm dedicated to helping you find the perfect Tata vehicle to suit your needs and lifestyle. Whether you're looking for a reliable daily driver, a spacious family SUV, or a stylish hatchback, I'm here to provide personalized guidance and assistance. From exploring the latest models and features to discussing financing options and after-sales services, I'll ensure a seamless and enjoyable car-buying experience.
                            <a href="book.php">
                            <button class="btn btn-green text-white rounded-0 mt-5">BOOK NOW</button>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="second-image">
                    <div class="blue-box">
                        <img src="images/services/cons.png" alt="Consultation">
                    </div>
                </div>
            </div>
        </div>

        <!-- Car Booking -->
        <div class="service-item">
            <h2>Car Booking</h2>
            <div class="service-images">
                <div class="first-image">
                    <div class="green-box">
                        <img src="images/services/book.jpg" alt="Car Booking">
                        <div class="description">
                        Online car booking of Tata cars is a convenient and efficient way to secure your desired vehicle. By visiting the Tata Motors website, you can explore the available models, customize your car according to your preferences, and make a reservation with a few simple clicks. With online booking, you can avoid long queues at dealerships and enjoy the flexibility of booking your car from the comfort of your home.
                            <a href="book.php">
                            <button class="btn btn-green text-white rounded-0 mt-5">BOOK NOW</button>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="second-image">
                    <div class="blue-box">
                        <img src="images/services/book2.jpg" alt="Test Drive Booking">
                    </div>
                </div>
            </div>
        </div>

        <!-- Maintenance and Repair -->
        <div class="service-item">
            <h2>Maintenance and Repair</h2>
            <div class="service-images">
                <div class="first-image">
                    <div class="green-box">
                        <img src="images/services/repair.jpg" alt="Car Maintenance">
                        <div class="description">
                        Maintaining and repairing your Tata car is essential to ensure its longevity and performance. Regular servicing, including oil changes, tire rotations, and brake inspections, can help prevent costly repairs and keep your vehicle running smoothly. Tata Motors offers a comprehensive range of after-sales services and genuine spare parts to support your car's maintenance needs. Additionally, you can find authorized service centers and skilled technicians across India to provide expert care for your Tata vehicle.
                            <a href="book.php">
                            <button class="btn btn-green text-white rounded-0 mt-5">BOOK NOW</button>
                        </a>
                        </div>

                    </div>
                </div>
                <div class="second-image">
                    <div class="blue-box">
                        <img src="images/services/maintainence.jpg" alt="Car Repair">
                    </div>
                </div>
            </div>
        </div>
                       <!-- after care -->
   
    
       <div class="service-item">
            <h2>After Sales Care</h2>
            <div class="service-images">
                <div class="first-image">
                    <div class="green-box">
                        <img src="images/services/after.jpg" alt="Car Maintenance">
                        <div class="description">
                        Tata Motors offers a comprehensive range of after-sales services to ensure your complete satisfaction. From routine maintenance and repairs to extended warranties and roadside assistance, our dedicated service network is committed to providing top-quality care for your Tata car. With authorized service centers conveniently located across India, you can easily access expert technicians and genuine spare parts to keep your vehicle running at its best. 
                            <a href="book.php">
                            <button class="btn btn-green text-white rounded-0 mt-5">BOOK NOW</button>
                        </a>
                        </div>

                    </div>
                </div>
                <div class="second-image">
                    <div class="blue-box">
                        <img src="images/services/after1.jpg" alt="Car Repair">
                    </div>
                </div>
            </div>
        </div>
   

                  <!-- contact us -->

                  <div class="service-item">
            <h2>Customer Support</h2>
            <div class="service-images">
                <div class="first-image">
                    <div class="green-box">
                        <img src="images/services/contact.png" alt="Car Maintenance">
                        <div class="description">
                           Tata Motors' customer support is designed to provide you with a seamless and satisfying ownership experience. Our dedicated customer care team is available to assist you with any inquiries, concerns, or issues related to your Tata car. Whether you need help with booking a service appointment, understanding your warranty coverage, or resolving a technical problem, we are committed to providing prompt and efficient assistance. You can reach out to our customer support team through various channels, including phone, email, and online chat.
                            <a href="message.php">
                            <button class="btn btn-green text-white rounded-0 mt-5">BOOK NOW</button>
                        </a>
                        </div>

                    </div>
                </div>
                <div class="second-image">
                    <div class="blue-box">
                        <img src="images/services/contact1.jpg" alt="Car Repair">
                    </div>
                </div>
            </div>
        </div>
   
    </div>

    

    
 <!-- Footer Start -->
 <footer>
 <div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container py-5">
                <div class="row g-5">
                    <div class="col-lg-3 col-md-6">
					<h5 class="text-white mb-4">Our Work Place</h5>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Maharshi Gurukul,Ranekpar Road,Halvad,Gujarat</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>8200249640</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>6351771401</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>tatacars770@gmail.com</p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Quick Links</h5>
                        <a class="btn btn-link text-white-50" href="">Services</a>
                        <a class="btn btn-link text-white-50" href="accessories.php">Accessories</a>
                        <a class="btn btn-link text-white-50" href="">New Item</a>
                        <a class="btn btn-link text-white-50" href="">About Us</a>
                        <a class="btn btn-link text-white-50" href="">Contact Us</a>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Photo Gallery</h5>
                        <div class="row g-2 pt-2">
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/punch.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/safari.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/nexon.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/harrier.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/happy.jpg" alt="">
                            </div>
                            <div class="col-4">
                                <img class="img-fluid rounded bg-light p-1" src="images/service.jpg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <h5 class="text-white mb-4">Newsletter</h5>
                        <p>
"Drive the Future with Tata: Innovation, Reliability, Excellence."</p>
                        <div class="position-relative mx-auto" style="max-width: 400px;">
                           
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="">Home</a>
                                <a href="">Cookies</a>
                                <a href="">Help</a>
                                <a href="">FQAs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->

		<a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
