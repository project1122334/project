<?php 
session_start();
include '../connect.php'; // Ensure you include your database connection file

// Check if user is logged in
if (!isset($_SESSION['firstName']) || !isset($_SESSION['lastName'])) {
    echo "<script>alert('Please login to view your bookings.'); window.location.href = '../login.php';</script>";
    exit();
}

$firstName = $_SESSION['firstName'];
$lastName = $_SESSION['lastName'];

// Fetch car bookings
$sqlCar = "SELECT * FROM car_bookings WHERE firstName = ? AND lastName = ?";
$stmtCar = $conn->prepare($sqlCar);
$stmtCar->bind_param("ss", $firstName, $lastName);
$stmtCar->execute();
$resultCarBookings = $stmtCar->get_result();

// Fetch test drive bookings
$sqlTestDrive = "SELECT * FROM test_bookings WHERE firstName = ? AND lastName = ?";
$stmtTestDrive = $conn->prepare($sqlTestDrive);
$stmtTestDrive->bind_param("ss", $firstName, $lastName);
$stmtTestDrive->execute();
$resultTestDriveBookings = $stmtTestDrive->get_result();

// Fetch repair bookings
$sqlRepair = "SELECT * FROM repair_booking WHERE firstName = ? AND lastName = ?";
$stmtRepair = $conn->prepare($sqlRepair);
$stmtRepair->bind_param("ss", $firstName, $lastName);
$stmtRepair->execute();
$resultRepairBookings = $stmtRepair->get_result();

// Handle booking removal
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['remove_booking'])) {
    $bookingId = $_POST['booking_id'];

    // Prepare and execute the removal query
    $deleteStmt = $conn->prepare("DELETE FROM car_bookings WHERE id = ? AND firstName = ? AND lastName = ?");
    $deleteStmt->bind_param("iss", $bookingId, $firstName, $lastName);

    if ($deleteStmt->execute()) {
        echo "<script>alert('Booking removed successfully.'); window.location.href = 'status.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href = 'status.php';</script>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['remove_test_drive_booking'])) {
    $bookingId = $_POST['booking_id'];

    // Prepare and execute the removal query
    $deleteStmt = $conn->prepare("DELETE FROM test_bookings WHERE id = ? AND firstName = ? AND lastName = ?");
    $deleteStmt->bind_param("iss", $bookingId, $firstName, $lastName);

    if ($deleteStmt->execute()) {
        echo "<script>alert('Test Drive Booking removed successfully.'); window.location.href = 'status.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href = 'status.php';</script>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['remove_repair_booking'])) {
    $bookingId = $_POST['booking_id'];

    // Prepare and execute the removal query
    $deleteStmt = $conn->prepare("DELETE FROM repair_booking WHERE id = ? AND firstName = ? AND lastName = ?");
    $deleteStmt->bind_param("iss", $bookingId, $firstName, $lastName);

    if ($deleteStmt->execute()) {
        echo "<script>alert('Test Drive Booking removed successfully.'); window.location.href = 'status.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href = 'status.php';</script>";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" />
    <title>My Bookings</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap");
        body, button {
            font-family: "Inter", sans-serif;
        }
        :root {
            --offcanvas-width: 270px;
            --topNavbarHeight: 56px;
        }
        body {
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .container {
            margin-top: 1rem; /* Adjust as necessary to avoid overlap with fixed navbar */
        }
        .table thead tr {
            background-color: #343a40; /* Dark Gray for Header */
            color: white; /* White text */
        }
        .table tbody tr {
            background-color: #2C2C2C; /* Slightly lighter dark gray for rows */
            color: white; /* White text */
        }
        .table tbody tr:hover {
            background-color: #3e3e3e; /* Slightly brighter dark gray for row hover */
        }
        .banner {
            background: url(../images/book2.jpg);
            background-position: center;
            background-size: cover;
            height: 70vh;
        }
        .bg-new {
            background: transparent;
        }
        .bg-green {
            background-color: #03de1c;
        }
        .text-green {
            color: #03de1c;
        }
        .h1 {
            font-size: 65px;
            font-weight: 700;
        }
        .btn-green {
            background-color: #03de1c;
            width: 190px;
            height: 47px;
        }
        .logo img {
            width: 50px;
        }
    </style>
</head>
<body>
<div class="banner">
    <nav class="navbar navbar-expand-lg bg-new pt-4 px-3">
        <a class="logo" href="#"><img src="../images/image.jpg" alt="..."></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon bg-green"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item mx-2 bg-green">
                    <a class="nav-link text-white" href="../homepage.php">HOME</a>
                </li>
                <li class="nav-item mx-2">
                    <a class="nav-link text-white" href="#">Services</a>
                </li>
                <li class="nav-item mx-2">
                    <a class="nav-link text-white" href="../accessories.php">Accessories</a>
                </li>
                <li class="nav-item mx-2">
                    <a class="nav-link text-white" href="#">New Item</a>
                </li>
                <li class="nav-item mx-2">
                    <a class="nav-link text-white" href="#">About</a>
                </li>
                <li class="nav-item mx-2">
                    <a class="nav-link text-white" href="#">Contact Us</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Page Content -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 text-white" style="padding-right: 19cm;">
                <h1>RIDE RIGHT<br>BOOK RIGHT</h1>
            </div>
        </div>
    </div>
</div>

<!-- Main content -->
<main>
    <div class="container">
        <h1 class="mb-4">My Car Bookings</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Car Model</th>
                    <th>Booking Date</th>
                    <th>Contact Number</th>
                    <th>Address</th>
                    <th>Car Color</th>
                    <th>Payment Type</th>
                    <th>Insurance Type</th>
                    <th>Aadhar Number</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($resultCarBookings->num_rows > 0): ?>
                    <?php while($row = $resultCarBookings->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id']); ?></td>
                            <td><?php echo htmlspecialchars($row['carModel']); ?></td>
                            <td><?php echo htmlspecialchars($row['bookingDate']); ?></td>
                            <td><?php echo htmlspecialchars($row['contactNumber']); ?></td>
                            <td><?php echo htmlspecialchars($row['address']); ?></td>
                            <td><?php echo htmlspecialchars($row['carColor']); ?></td>
                            <td><?php echo htmlspecialchars($row['paymentType']); ?></td>
                            <td><?php echo htmlspecialchars($row['insuranceType']); ?></td>
                            <td><?php echo htmlspecialchars($row['aadharNumber']); ?></td>
                            <td>
                                <form action="" method="post" style="display:inline;">
                                    <input type="hidden" name="booking_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                    <button type="submit" name="remove_booking" class="btn btn-danger btn-sm">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10">No car bookings found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div style="margin-top: 3rem;"></div> <!-- Space between sections -->

     <h1 class="mb-4">My Test Drive Bookings</h1>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>Phone Number</th>
                        <th>Car Model</th>
                        <th>Test Drive Date</th>
                        <th>Test Drive Time</th>
                        <th>Pickup Location</th>
                        <th>Custom Location</th>
                        <th>Aadhar Card</th>
                        <th>Transmission Type</th>
                        <th>Fuel Type</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($resultTestDriveBookings->num_rows > 0): ?>
                        <?php while($row = $resultTestDriveBookings->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                <td><?php echo htmlspecialchars($row['fullName']); ?></td>
                                <td><?php echo htmlspecialchars($row['phoneNumber']); ?></td>
                                <td><?php echo htmlspecialchars($row['carModel']); ?></td>
                                <td><?php echo htmlspecialchars($row['testDriveDate']); ?></td>
                                <td><?php echo htmlspecialchars($row['testDriveTime']); ?></td>
                                <td><?php echo htmlspecialchars($row['pickupLocation']); ?></td>
                                <td><?php echo htmlspecialchars($row['customLocation']); ?></td>
                                <td><?php echo htmlspecialchars($row['aadharCard']); ?></td>
                                <td><?php echo htmlspecialchars($row['transmissionType']); ?></td>
                                <td><?php echo htmlspecialchars($row['fuelType']); ?></td>
                                <td>
                                    <form action="" method="post" style="display:inline;">
                                        <input type="hidden" name="booking_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                                        <button type="submit" name="remove_test_drive_booking" class="btn btn-danger btn-sm">Remove</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="12">No test drive bookings found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <div style="margin-top: 3rem;"></div> <!-- Space between sections -->

<h1 class="mb-4">My Repair Bookings</h1>
<table class="table">
            <thead>
                <tr>
                    <th scope="col">id</th>
                    <th scope="col">First Name</th>
                    <th scope="col">Last Name</th>
                    <th scope="col">Car Model</th>
                    <th scope="col">Damage Type</th>
                    <th scope="col">other damage</th>
                    <th scope="col">Contact Number</th>
                    <th scope="col">Repair Date</th>
                    <th scope="col">Aadhar Number</th>
                    <th scope="col">Photo</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
    <?php if ($resultRepairBookings->num_rows > 0): ?>
        <?php while($row = $resultRepairBookings->fetch_assoc()): ?>
            <tr>
                <th scope="row"><?php echo htmlspecialchars($row['id']); ?></th>
                <td><?php echo htmlspecialchars($row['firstName']); ?></td>
                <td><?php echo htmlspecialchars($row['lastName']); ?></td>
                <td><?php echo htmlspecialchars($row['carModel']); ?></td>
                <td><?php echo htmlspecialchars($row['damageType']); ?></td>
                <td><?php echo htmlspecialchars($row['otherDamage']); ?></td>
                <td><?php echo htmlspecialchars($row['contactNumber']); ?></td>
                <td><?php echo htmlspecialchars($row['repairDate']); ?></td>
                <td><?php echo htmlspecialchars($row['aadharNumber']); ?></td>
                <td>
                    <?php if (!empty($row['photoPath'])): ?>
                        <a href="<?php echo htmlspecialchars($row['photoPath']); ?>" target="_blank">View Photo</a>
                    <?php else: ?>
                        No Photo
                    <?php endif; ?>
                </td>
                <td>
                    <form action="" method="post" style="display:inline;">
                        <input type="hidden" name="booking_id" value="<?php echo htmlspecialchars($row['id']); ?>">
                        <button type="submit" name="remove_repair_booking" class="btn btn-danger btn-sm">Remove</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="11">No repair bookings found.</td>
        </tr>
    <?php endif; ?>
</tbody>

        </table>
    </div>
</main>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
