<?php
session_start();
include('../connect.php'); // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_photo'])) {
    $file = $_FILES['profile_photo'];

    // Check if a file was uploaded
    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        die("No file was uploaded.");
    }

    // Validate the file upload
    if ($file['error'] !== UPLOAD_ERR_OK) {
        die("Upload failed with error code " . $file['error']);
    }
    $fileName = basename($file['name']);
    $filePath = '../uploads/' . $fileName; // Adjust the path as needed

    // Ensure the upload directory exists
    if (!is_dir('../uploads')) {
        mkdir('../uploads', 0777, true);
    }

    // Move the uploaded file to the target directory
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        $userId = $_SESSION['id']; // Assuming user ID is stored in session

        // Update the database with the new profile photo path
        $stmt = $conn->prepare("UPDATE users SET profile_photo = ? WHERE id = ?");
        $stmt->bind_param('si', $filePath, $userId);
        if ($stmt->execute()) {
            // Store the profile photo path in the session
            $_SESSION['profilePhoto'] = $filePath;

            // Optionally set a success message or redirect
            header('Location: ../homepage.php'); // Redirect to homepage or any other page
            exit();
        } else {
            echo "Failed to update profile photo in the database.";
        }
        $stmt->close();
    } else {
        echo "Failed to move uploaded file.";
    }
} else {
    echo "No file uploaded or invalid request.";
}
?>
